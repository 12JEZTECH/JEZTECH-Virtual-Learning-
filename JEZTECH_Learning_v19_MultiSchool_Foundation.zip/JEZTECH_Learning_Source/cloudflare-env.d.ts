declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    WORKSPACE_SERVICE_TOKEN?: string;
    BUCKET?: R2Bucket;
  }
}
declare namespace Cloudflare {
 interface Env {
  MPESA_CONSUMER_KEY?:string;
  MPESA_CONSUMER_SECRET?:string;
  MPESA_PASSKEY?:string;
  MPESA_SHORTCODE?:string;
  MPESA_CALLBACK_URL?:string;
  MPESA_LIVE_ENABLED?:string;
 }
}
