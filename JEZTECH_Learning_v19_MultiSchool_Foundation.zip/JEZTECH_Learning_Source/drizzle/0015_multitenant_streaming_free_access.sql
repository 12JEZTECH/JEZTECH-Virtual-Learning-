-- JEZTECH v19: additive multi-school and promotional-access foundation
CREATE TABLE IF NOT EXISTS school_tenants (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
 status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tenant_memberships (
 tenant_id TEXT NOT NULL REFERENCES school_tenants(id), user_id TEXT NOT NULL REFERENCES users(id),
 role TEXT NOT NULL CHECK(role IN ('school_admin','teacher','student')),
 status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL,
 PRIMARY KEY(tenant_id,user_id)
);
CREATE INDEX IF NOT EXISTS tenant_memberships_user ON tenant_memberships(user_id);
CREATE TABLE IF NOT EXISTS tenant_subscriptions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES school_tenants(id),
 plan_name TEXT NOT NULL, starts_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS class_channels (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES school_tenants(id),
 curriculum TEXT NOT NULL, level TEXT NOT NULL, title TEXT NOT NULL,
 teacher_id TEXT REFERENCES users(id), created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS class_channels_tenant_level ON class_channels(tenant_id,level);
CREATE TABLE IF NOT EXISTS class_enrollments (
 channel_id TEXT NOT NULL REFERENCES class_channels(id), student_id TEXT NOT NULL REFERENCES users(id),
 enrolled_at INTEGER NOT NULL, PRIMARY KEY(channel_id,student_id)
);
CREATE TABLE IF NOT EXISTS class_streams (
 id TEXT PRIMARY KEY, channel_id TEXT NOT NULL REFERENCES class_channels(id),
 teacher_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL,
 stream_url TEXT, scheduled_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled',
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS free_access_grants (
 id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES users(id),
 tenant_id TEXT REFERENCES school_tenants(id), scope TEXT NOT NULL DEFAULT 'all_materials',
 starts_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 granted_by TEXT NOT NULL REFERENCES users(id), reason TEXT NOT NULL DEFAULT '',
 revoked_at INTEGER, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS free_access_active ON free_access_grants(student_id,expires_at);
CREATE TABLE IF NOT EXISTS admin_actions (
 id TEXT PRIMARY KEY, actor_id TEXT NOT NULL REFERENCES users(id), action TEXT NOT NULL,
 subject_id TEXT, metadata TEXT NOT NULL DEFAULT '{}', created_at INTEGER NOT NULL
);
