-- JEZTECH Learning v18: registration, trial access and payment reconciliation
-- Additive migration. Existing learner and subscription records are preserved.
ALTER TABLE payment_intents ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'tuition';
ALTER TABLE payment_intents ADD COLUMN account_reference TEXT NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS registration_fee_settings (
  id TEXT PRIMARY KEY,
  amount INTEGER NOT NULL DEFAULT 0,
  business_number TEXT NOT NULL DEFAULT '',
  account_reference_prefix TEXT NOT NULL DEFAULT 'REG',
  instructions TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS registration_fee_payments (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES users(id),
  phone TEXT NOT NULL,
  receipt TEXT NOT NULL UNIQUE,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by TEXT REFERENCES users(id),
  review_note TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  reviewed_at INTEGER
);
CREATE INDEX IF NOT EXISTS registration_fee_student
  ON registration_fee_payments(student_id, created_at);

CREATE TABLE IF NOT EXISTS payment_reconciliation_batches (
  id TEXT PRIMARY KEY,
  batch_reference TEXT NOT NULL UNIQUE,
  period_start INTEGER,
  period_end INTEGER,
  total_received INTEGER NOT NULL DEFAULT 0,
  total_matched INTEGER NOT NULL DEFAULT 0,
  total_unmatched INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);

CREATE TABLE IF NOT EXISTS payment_reconciliation_items (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES payment_reconciliation_batches(id),
  payment_type TEXT NOT NULL CHECK(payment_type IN ('registration','tuition')),
  external_reference TEXT NOT NULL,
  student_id TEXT REFERENCES users(id),
  payment_id TEXT,
  expected_amount INTEGER,
  received_amount INTEGER NOT NULL,
  match_status TEXT NOT NULL DEFAULT 'unmatched',
  exception_reason TEXT NOT NULL DEFAULT '',
  reviewed_by TEXT REFERENCES users(id),
  reviewed_at INTEGER,
  created_at INTEGER NOT NULL,
  UNIQUE(batch_id, external_reference)
);

CREATE TABLE IF NOT EXISTS learner_trial_access (
  student_id TEXT PRIMARY KEY REFERENCES users(id),
  starts_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  granted_by TEXT REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS trial_expiry ON learner_trial_access(expires_at);
