import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
fs.mkdirSync('.sites-runtime',{recursive:true});
fs.writeFileSync('.sites-runtime/curriculum-import-test.mjs',ts.transpileModule(fs.readFileSync('app/curriculum/import.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
const {parseTopics}=await import('../.sites-runtime/curriculum-import-test.mjs');
test('CSV imports preserve quoted commas, newlines and escaped quotes',()=>{
 assert.deepEqual(parseTopics('\uFEFFtopic,notes\r\n"Data, graphs","Explain \"\"units\"\"\nand scales"\r\nAlgebra,\r\n','csv'),[{title:'Data, graphs',notes:'Explain "units"\nand scales'},{title:'Algebra',notes:''}]);
});
test('plain outlines and malformed/oversized imports have clear validation',()=>{
 assert.deepEqual(parseTopics('Numbers\r\n\r\nAlgebra','txt'),[{title:'Numbers',notes:''},{title:'Algebra',notes:''}]);
 assert.throws(()=>parseTopics('title,notes\nA,B','csv'),/topic header/);
 assert.throws(()=>parseTopics('topic,notes\n"Unclosed','csv'),/closing quote/);
 assert.throws(()=>parseTopics('x'.repeat(120001),'txt'),/120 KB/);
 assert.throws(()=>parseTopics('a\n'.repeat(101),'txt'),/100 topics/);
});
test('official design catalogue has one source per subject and grade and flags known mismatch',()=>{
 const docs=JSON.parse(fs.readFileSync('app/curriculum/documents.json','utf8'));
 assert.equal(docs.length,165);assert.equal(new Set(docs.map(d=>d.level+':'+d.subject)).size,165);
 for(const d of docs){assert.match(d.preview,/^https:\/\/drive\.google\.com\/file\/d\/[\w-]+\/preview$/);assert.equal(new URL(d.source).hostname,'kicd.ac.ke');}
 for(const grade of [7,8,9,10,11,12])assert.equal(docs.filter(d=>d.level==='grade-'+grade).length,grade<10?16:39);
 assert.equal(docs.find(d=>d.level==='grade-10'&&d.subject==='marine-fisheries').gradeWarning,true);
});
test('practical videos are verified MP4 resources hosted on the official source',()=>{
 const videos=JSON.parse(fs.readFileSync('app/curriculum/videos.json','utf8'));assert.equal(videos.length,6);
 for(const v of videos){assert.equal(v.verifiedMedia,true);assert.equal(new URL(v.url).hostname,'lms.kec.ac.ke');assert.match(v.url,/\.mp4$/);assert.equal(new URL(v.source).hostname,'lms.kec.ac.ke');}
});
