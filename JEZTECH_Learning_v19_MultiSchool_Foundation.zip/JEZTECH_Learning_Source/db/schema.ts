import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const users = sqliteTable('users', {
  id: text('id').primaryKey(), email: text('email').notNull(), name: text('name').notNull(),
  role: text('role', {enum:['admin','teacher','student']}).notNull().default('student'),
  disabled: integer('disabled').notNull().default(0), createdAt: integer('created_at').notNull(),
});
export const exams = sqliteTable('exams', {
  id:text('id').primaryKey(), teacherId:text('teacher_id').notNull().references(()=>users.id),
  title:text('title').notNull(), description:text('description').notNull().default(''),
  duration:integer('duration').notNull(), status:text('status').notNull().default('draft'),
  startsAt:integer('starts_at'), endsAt:integer('ends_at'), createdAt:integer('created_at').notNull(),
},t=>[index('exams_teacher').on(t.teacherId)]);
export const questions = sqliteTable('questions', {
  id:text('id').primaryKey(), examId:text('exam_id').notNull().references(()=>exams.id),
  position:integer('position').notNull(), text:text('text').notNull(), choices:text('choices').notNull(), correct:integer('correct').notNull(),
},t=>[uniqueIndex('questions_exam_position').on(t.examId,t.position)]);
export const sessions = sqliteTable('sessions', {
  id:text('id').primaryKey(), examId:text('exam_id').notNull().references(()=>exams.id), studentId:text('student_id').notNull().references(()=>users.id),
  status:text('status').notNull().default('active'), answers:text('answers').notNull().default('{}'),
  warnings:integer('warnings').notNull().default(0), flagged:integer('flagged').notNull().default(0),
  startedAt:integer('started_at').notNull(), deadline:integer('deadline').notNull(), remainingMs:integer('remaining_ms'),
  lastSeen:integer('last_seen').notNull(), endedAt:integer('ended_at'), score:integer('score'), total:integer('total').notNull(),
},t=>[uniqueIndex('session_one_attempt').on(t.examId,t.studentId),index('sessions_state_deadline').on(t.status,t.deadline)]);
export const events = sqliteTable('events', {
  id:text('id').primaryKey(), sessionId:text('session_id').notNull().references(()=>sessions.id), actorId:text('actor_id').notNull().references(()=>users.id),
  code:text('code').notNull(), message:text('message').notNull(), at:integer('at').notNull(),
},t=>[index('events_session_time').on(t.sessionId,t.at)]);
export const lessons = sqliteTable('lessons', {
 id:text('id').primaryKey(),classLevel:text('class_level').notNull().default('all'),topic:text('topic').notNull().default(''),teacherId:text('teacher_id').notNull().references(()=>users.id),title:text('title').notNull(),summary:text('summary').notNull(),content:text('content').notNull(),
 subject:text('subject').notNull(),curriculum:text('curriculum').notNull(),price:integer('price').notNull().default(50),status:text('status').notNull().default('published'),createdAt:integer('created_at').notNull(),
},t=>[index('lessons_teacher').on(t.teacherId)]);
export const payments = sqliteTable('payments', {
 id:text('id').primaryKey(),lessonId:text('lesson_id').notNull().references(()=>lessons.id),studentId:text('student_id').notNull().references(()=>users.id),
 phone:text('phone').notNull(),amount:integer('amount').notNull(),receipt:text('receipt').notNull(),status:text('status').notNull().default('pending'),
 reviewedBy:text('reviewed_by').references(()=>users.id),reviewNote:text('review_note').notNull().default(''),createdAt:integer('created_at').notNull(),reviewedAt:integer('reviewed_at'),
},t=>[uniqueIndex('payments_receipt').on(t.receipt),index('payments_student_lesson').on(t.studentId,t.lessonId)]);
export const paymentSettings=sqliteTable('payment_settings',{
 id:text('id').primaryKey(),businessNumber:text('business_number').notNull().default(''),accountReference:text('account_reference').notNull().default(''),instructions:text('instructions').notNull().default(''),updatedAt:integer('updated_at').notNull(),
});
export const labs=sqliteTable('labs',{
 classLevel:text('class_level').notNull().default('all'),topic:text('topic').notNull().default(''),
 id:text('id').primaryKey(),teacherId:text('teacher_id').notNull().references(()=>users.id),title:text('title').notNull(),subject:text('subject').notNull(),curriculum:text('curriculum').notNull(),
 safety:text('safety').notNull(),duration:integer('duration').notNull(),benchCount:integer('bench_count').notNull(),apparatusIds:text('apparatus_ids').notNull(),questions:text('questions').notNull(),rubric:text('rubric').notNull(),
 status:text('status').notNull().default('active'),startedAt:integer('started_at').notNull(),deadline:integer('deadline').notNull(),endedAt:integer('ended_at'),
},t=>[index('labs_teacher').on(t.teacherId)]);
export const labEntries=sqliteTable('lab_entries',{
 id:text('id').primaryKey(),labId:text('lab_id').notNull().references(()=>labs.id),studentId:text('student_id').notNull().references(()=>users.id),bench:integer('bench'),ready:integer('ready').notNull().default(0),
 answers:text('answers').notNull().default('{}'),equipment:text('equipment').notNull().default('{}'),selfRubric:text('self_rubric').notNull().default('{}'),teacherRubric:text('teacher_rubric').notNull().default('{}'),
 notes:text('notes').notNull().default(''),status:text('status').notNull().default('active'),score:integer('score'),maxScore:integer('max_score'),perQuestion:text('per_question').notNull().default('{}'),
 feedback:text('feedback').notNull().default(''),lastSeen:integer('last_seen').notNull(),submittedAt:integer('submitted_at'),version:integer('version').notNull().default(0),
},t=>[uniqueIndex('one_lab_entry').on(t.labId,t.studentId),index('lab_entries_lab_status').on(t.labId,t.status)]);
export const admissions=sqliteTable('admissions',{
 studentId:text('student_id').primaryKey().references(()=>users.id),teacherId:text('teacher_id').notNull().references(()=>users.id),phone:text('phone').notNull(),level:text('level').notNull(),goals:text('goals').notNull(),
 status:text('status').notNull().default('pending'),note:text('note').notNull().default(''),requestedAt:integer('requested_at').notNull(),reviewedAt:integer('reviewed_at'),
});
export const learningPresence=sqliteTable('learning_presence',{
 studentId:text('student_id').primaryKey().references(()=>users.id),lastSeen:integer('last_seen').notNull(),page:text('page').notNull(),handRaised:integer('hand_raised').notNull().default(0),handNote:text('hand_note').notNull().default(''),raisedAt:integer('raised_at'),
});
export const learnerQuestions=sqliteTable('learner_questions',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),teacherId:text('teacher_id').notNull().references(()=>users.id),lessonId:text('lesson_id').references(()=>lessons.id),question:text('question').notNull(),answer:text('answer').notNull().default(''),source:text('source').notNull().default('pending'),status:text('status').notNull().default('pending'),createdAt:integer('created_at').notNull(),answeredAt:integer('answered_at'),
},t=>[index('questions_daily_teacher').on(t.teacherId,t.createdAt)]);
export const learningDays=sqliteTable('learning_days',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),lessonId:text('lesson_id').notNull().references(()=>lessons.id),day:text('day').notNull(),at:integer('at').notNull(),
},t=>[uniqueIndex('one_lesson_day').on(t.studentId,t.lessonId,t.day)]);
export const assessmentCycles=sqliteTable('assessment_cycles',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),teacherId:text('teacher_id').notNull().references(()=>users.id),cycle:integer('cycle').notNull(),examId:text('exam_id').references(()=>exams.id),status:text('status').notNull().default('pending'),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('one_assessment_cycle').on(t.studentId,t.cycle)]);
export const dailyReports=sqliteTable('daily_reports',{
 id:text('id').primaryKey(),teacherId:text('teacher_id').notNull().references(()=>users.id),day:text('day').notNull(),data:text('data').notNull(),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('one_teacher_daily_report').on(t.teacherId,t.day)]);
export const subscriptionSettings=sqliteTable('subscription_settings',{
 id:text('id').primaryKey(),price:integer('price').notNull().default(0),days:integer('days').notNull().default(30),updatedAt:integer('updated_at').notNull(),
});
export const subscriptions=sqliteTable('subscriptions',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),phone:text('phone').notNull(),receipt:text('receipt').notNull(),amount:integer('amount').notNull(),days:integer('days').notNull(),status:text('status').notNull().default('pending'),verifiedAt:integer('verified_at'),expiresAt:integer('expires_at'),note:text('note').notNull().default(''),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('subscription_receipt').on(t.receipt)]);
export const videoCredits=sqliteTable('video_credits',{
 studentId:text('student_id').primaryKey().references(()=>users.id),allowance:integer('allowance').notNull().default(1200),used:integer('used').notNull().default(0),leaseId:text('lease_id'),leaseExpires:integer('lease_expires'),grantedAt:integer('granted_at').notNull(),
});
export const learningVideos=sqliteTable('learning_videos',{
 id:text('id').primaryKey(),teacherId:text('teacher_id').notNull().references(()=>users.id),title:text('title').notNull(),url:text('url').notNull(),experiment:text('experiment').notNull().default('general'),explanation:text('explanation').notNull().default(''),createdAt:integer('created_at').notNull(),
});
export const notices=sqliteTable('notices',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),kind:text('kind').notNull(),ref:text('ref').notNull(),message:text('message').notNull(),createdAt:integer('created_at').notNull(),readAt:integer('read_at'),
},t=>[uniqueIndex('one_notice_ref').on(t.studentId,t.kind,t.ref)]);
export const teacherAccounts=sqliteTable('teacher_accounts',{
 id:text('id').primaryKey(),email:text('email').notNull(),fullName:text('full_name').notNull(),phone:text('phone').notNull().default(''),subject:text('subject').notNull().default(''),
 status:text('status').notNull().default('pending'),userId:text('user_id').references(()=>users.id),createdBy:text('created_by').notNull().references(()=>users.id),createdAt:integer('created_at').notNull(),activatedAt:integer('activated_at'),
},t=>[uniqueIndex('teacher_account_email').on(t.email)]);
export const learnerAccess=sqliteTable('learner_access',{
 studentId:text('student_id').primaryKey().references(()=>users.id),loginId:text('login_id').notNull(),expiresAt:integer('expires_at').notNull(),issuedAt:integer('issued_at').notNull(),
},t=>[uniqueIndex('learner_login_id').on(t.loginId)]);
export const classroomRooms=sqliteTable('classroom_rooms',{
 id:text('id').primaryKey(),teacherId:text('teacher_id').notNull().references(()=>users.id),name:text('name').notNull(),description:text('description').notNull().default(''),createdAt:integer('created_at').notNull(),
});
export const classroomCalls=sqliteTable('classroom_calls',{
 id:text('id').primaryKey(),roomId:text('room_id').notNull().references(()=>classroomRooms.id),studentId:text('student_id').notNull().references(()=>users.id),teacherId:text('teacher_id').notNull().references(()=>users.id),
 topic:text('topic').notNull(),status:text('status').notNull().default('waiting'),createdAt:integer('created_at').notNull(),acceptedAt:integer('accepted_at'),endedAt:integer('ended_at'),lastSeen:integer('last_seen').notNull(),
},t=>[index('calls_room_status').on(t.roomId,t.status)]);
export const callSignals=sqliteTable('call_signals',{
 id:integer('id').primaryKey({autoIncrement:true}),callId:text('call_id').notNull().references(()=>classroomCalls.id),senderId:text('sender_id').notNull().references(()=>users.id),type:text('type').notNull(),payload:text('payload').notNull(),createdAt:integer('created_at').notNull(),
},t=>[index('signals_call_id').on(t.callId,t.id)]);
export const cctvCameras=sqliteTable('cctv_cameras',{
 id:text('id').primaryKey(),roomId:text('room_id').notNull().references(()=>classroomRooms.id),name:text('name').notNull(),url:text('url').notNull(),format:text('format').notNull(),enabled:integer('enabled').notNull().default(1),createdAt:integer('created_at').notNull(),
});
export const virtualRuns=sqliteTable('virtual_runs',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),experiment:text('experiment').notNull(),inputs:text('inputs').notNull(),results:text('results').notNull(),notes:text('notes').notNull(),createdAt:integer('created_at').notNull(),
});
export const paymentAccessGrants=sqliteTable('payment_access_grants',{
 paymentId:text('payment_id').primaryKey().references(()=>payments.id),studentId:text('student_id').notNull().references(()=>users.id),expiresAt:integer('expires_at').notNull(),grantedAt:integer('granted_at').notNull(),
});
export const classSessions=sqliteTable('class_sessions',{
 id:text('id').primaryKey(),roomId:text('room_id').notNull().references(()=>classroomRooms.id),title:text('title').notNull(),status:text('status').notNull().default('preparing'),opensAt:integer('opens_at').notNull(),startsAt:integer('starts_at').notNull(),endedAt:integer('ended_at'),
},t=>[index('class_sessions_room').on(t.roomId,t.opensAt)]);
export const classAttendance=sqliteTable('class_attendance',{
 id:text('id').primaryKey(),sessionId:text('session_id').notNull().references(()=>classSessions.id),studentId:text('student_id').notNull().references(()=>users.id),joinedAt:integer('joined_at').notNull(),lastSeen:integer('last_seen').notNull(),ready:integer('ready').notNull().default(0),leftAt:integer('left_at'),cameraFrame:text('camera_frame'),cameraAt:integer('camera_at'),
},t=>[uniqueIndex('class_attendance_learner').on(t.sessionId,t.studentId)]);
export const paymentIntents=sqliteTable('payment_intents',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),phone:text('phone').notNull(),amount:integer('amount').notNull(),days:integer('days').notNull(),paymentType:text('payment_type').notNull().default('tuition'),accountReference:text('account_reference').notNull().default(''),status:text('status').notNull().default('starting'),checkoutId:text('checkout_id'),merchantId:text('merchant_id'),message:text('message').notNull().default(''),createdAt:integer('created_at').notNull(),checkedAt:integer('checked_at'),confirmedAt:integer('confirmed_at'),
},t=>[uniqueIndex('payment_intent_checkout').on(t.checkoutId),index('payment_intent_student').on(t.studentId,t.createdAt)]);
export const cctvMonitors=sqliteTable('cctv_monitors',{
 id:text('id').primaryKey(),roomId:text('room_id').notNull().references(()=>classroomRooms.id),teacherId:text('teacher_id').notNull().references(()=>users.id),createdBy:text('created_by').notNull().references(()=>users.id),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('cctv_monitor_room_teacher').on(t.roomId,t.teacherId)]);
export const teachingOutlines=sqliteTable('teaching_outlines',{
 id:text('id').primaryKey(),teacherId:text('teacher_id').notNull().references(()=>users.id),classLevel:text('class_level').notNull(),subject:text('subject').notNull(),title:text('title').notNull(),notes:text('notes').notNull().default(''),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('teaching_outline_topic').on(t.teacherId,t.classLevel,t.subject,t.title)]);
export const lessonAccessEvents=sqliteTable('lesson_access_events',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),teacherId:text('teacher_id').references(()=>users.id),resource:text('resource').notNull(),reason:text('reason').notNull(),bucket:integer('bucket').notNull(),attemptCount:integer('attempt_count').notNull().default(1),firstAt:integer('first_at').notNull(),lastAt:integer('last_at').notNull(),
},t=>[uniqueIndex('access_event_window').on(t.studentId,t.resource,t.reason,t.bucket),index('access_event_teacher').on(t.teacherId,t.lastAt)]);


// v18 registration, trial and reconciliation records
export const registrationFeeSettings=sqliteTable('registration_fee_settings',{
 id:text('id').primaryKey(),amount:integer('amount').notNull().default(0),businessNumber:text('business_number').notNull().default(''),
 accountReferencePrefix:text('account_reference_prefix').notNull().default('REG'),instructions:text('instructions').notNull().default(''),updatedAt:integer('updated_at').notNull(),
});
export const registrationFeePayments=sqliteTable('registration_fee_payments',{
 id:text('id').primaryKey(),studentId:text('student_id').notNull().references(()=>users.id),phone:text('phone').notNull(),receipt:text('receipt').notNull(),
 amount:integer('amount').notNull(),status:text('status').notNull().default('pending'),reviewedBy:text('reviewed_by').references(()=>users.id),
 reviewNote:text('review_note').notNull().default(''),createdAt:integer('created_at').notNull(),reviewedAt:integer('reviewed_at'),
},t=>[uniqueIndex('registration_fee_receipt').on(t.receipt),index('registration_fee_student').on(t.studentId,t.createdAt)]);
export const learnerTrialAccess=sqliteTable('learner_trial_access',{
 studentId:text('student_id').primaryKey().references(()=>users.id),startsAt:integer('starts_at').notNull(),expiresAt:integer('expires_at').notNull(),
 grantedBy:text('granted_by').references(()=>users.id),createdAt:integer('created_at').notNull(),
});
export const paymentReconciliationBatches=sqliteTable('payment_reconciliation_batches',{
 id:text('id').primaryKey(),batchReference:text('batch_reference').notNull(),periodStart:integer('period_start'),periodEnd:integer('period_end'),
 totalReceived:integer('total_received').notNull().default(0),totalMatched:integer('total_matched').notNull().default(0),totalUnmatched:integer('total_unmatched').notNull().default(0),
 status:text('status').notNull().default('open'),createdAt:integer('created_at').notNull(),closedAt:integer('closed_at'),
},t=>[uniqueIndex('reconciliation_batch_ref').on(t.batchReference)]);
export const paymentReconciliationItems=sqliteTable('payment_reconciliation_items',{
 id:text('id').primaryKey(),batchId:text('batch_id').notNull().references(()=>paymentReconciliationBatches.id),paymentType:text('payment_type').notNull(),
 externalReference:text('external_reference').notNull(),studentId:text('student_id').references(()=>users.id),paymentId:text('payment_id'),
 expectedAmount:integer('expected_amount'),receivedAmount:integer('received_amount').notNull(),matchStatus:text('match_status').notNull().default('unmatched'),
 exceptionReason:text('exception_reason').notNull().default(''),reviewedBy:text('reviewed_by').references(()=>users.id),reviewedAt:integer('reviewed_at'),createdAt:integer('created_at').notNull(),
},t=>[uniqueIndex('reconciliation_external_ref').on(t.batchId,t.externalReference)]);
