-- Empty database initialisation only; do not run against an existing database.

-- 0000_concerned_dexter_bennett.sql
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`code` text NOT NULL,
	`message` text NOT NULL,
	`at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`actor_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `events_session_time` ON `events` (`session_id`,`at`);--> statement-breakpoint
CREATE TABLE `exams` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`title` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`duration` integer NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`starts_at` integer,
	`ends_at` integer,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `exams_teacher` ON `exams` (`teacher_id`);--> statement-breakpoint
CREATE TABLE `questions` (
	`id` text PRIMARY KEY NOT NULL,
	`exam_id` text NOT NULL,
	`position` integer NOT NULL,
	`text` text NOT NULL,
	`choices` text NOT NULL,
	`correct` integer NOT NULL,
	FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `questions_exam_position` ON `questions` (`exam_id`,`position`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`exam_id` text NOT NULL,
	`student_id` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`answers` text DEFAULT '{}' NOT NULL,
	`warnings` integer DEFAULT 0 NOT NULL,
	`flagged` integer DEFAULT 0 NOT NULL,
	`started_at` integer NOT NULL,
	`deadline` integer NOT NULL,
	`remaining_ms` integer,
	`last_seen` integer NOT NULL,
	`ended_at` integer,
	`score` integer,
	`total` integer NOT NULL,
	FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `session_one_attempt` ON `sessions` (`exam_id`,`student_id`);--> statement-breakpoint
CREATE INDEX `sessions_state_deadline` ON `sessions` (`status`,`deadline`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`role` text DEFAULT 'student' NOT NULL,
	`disabled` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);


-- 0001_sloppy_puck.sql
CREATE TABLE `lab_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`lab_id` text NOT NULL,
	`student_id` text NOT NULL,
	`bench` integer,
	`ready` integer DEFAULT 0 NOT NULL,
	`answers` text DEFAULT '{}' NOT NULL,
	`equipment` text DEFAULT '{}' NOT NULL,
	`self_rubric` text DEFAULT '{}' NOT NULL,
	`teacher_rubric` text DEFAULT '{}' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`score` integer,
	`max_score` integer,
	`per_question` text DEFAULT '{}' NOT NULL,
	`feedback` text DEFAULT '' NOT NULL,
	`last_seen` integer NOT NULL,
	`submitted_at` integer,
	`version` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`lab_id`) REFERENCES `labs`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_lab_entry` ON `lab_entries` (`lab_id`,`student_id`);--> statement-breakpoint
CREATE INDEX `lab_entries_lab_status` ON `lab_entries` (`lab_id`,`status`);--> statement-breakpoint
CREATE TABLE `labs` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`title` text NOT NULL,
	`subject` text NOT NULL,
	`curriculum` text NOT NULL,
	`safety` text NOT NULL,
	`duration` integer NOT NULL,
	`bench_count` integer NOT NULL,
	`apparatus_ids` text NOT NULL,
	`questions` text NOT NULL,
	`rubric` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`started_at` integer NOT NULL,
	`deadline` integer NOT NULL,
	`ended_at` integer,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `labs_teacher` ON `labs` (`teacher_id`);--> statement-breakpoint
CREATE TABLE `lessons` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`title` text NOT NULL,
	`summary` text NOT NULL,
	`content` text NOT NULL,
	`subject` text NOT NULL,
	`curriculum` text NOT NULL,
	`price` integer DEFAULT 50 NOT NULL,
	`status` text DEFAULT 'published' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `lessons_teacher` ON `lessons` (`teacher_id`);--> statement-breakpoint
CREATE TABLE `payment_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`business_number` text DEFAULT '' NOT NULL,
	`account_reference` text DEFAULT '' NOT NULL,
	`instructions` text DEFAULT '' NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` text PRIMARY KEY NOT NULL,
	`lesson_id` text NOT NULL,
	`student_id` text NOT NULL,
	`phone` text NOT NULL,
	`amount` integer NOT NULL,
	`receipt` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`reviewed_by` text,
	`review_note` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	`reviewed_at` integer,
	FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `payments_receipt` ON `payments` (`receipt`);--> statement-breakpoint
CREATE INDEX `payments_student_lesson` ON `payments` (`student_id`,`lesson_id`);

-- 0002_fuzzy_captain_marvel.sql
CREATE TABLE `admissions` (
	`student_id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`phone` text NOT NULL,
	`level` text NOT NULL,
	`goals` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`requested_at` integer NOT NULL,
	`reviewed_at` integer,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `assessment_cycles` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`teacher_id` text NOT NULL,
	`cycle` integer NOT NULL,
	`exam_id` text,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_assessment_cycle` ON `assessment_cycles` (`student_id`,`cycle`);--> statement-breakpoint
CREATE TABLE `daily_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`day` text NOT NULL,
	`data` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_teacher_daily_report` ON `daily_reports` (`teacher_id`,`day`);--> statement-breakpoint
CREATE TABLE `learner_questions` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`teacher_id` text NOT NULL,
	`lesson_id` text,
	`question` text NOT NULL,
	`answer` text DEFAULT '' NOT NULL,
	`source` text DEFAULT 'pending' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` integer NOT NULL,
	`answered_at` integer,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `questions_daily_teacher` ON `learner_questions` (`teacher_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `learning_days` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`lesson_id` text NOT NULL,
	`day` text NOT NULL,
	`at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_lesson_day` ON `learning_days` (`student_id`,`lesson_id`,`day`);--> statement-breakpoint
CREATE TABLE `learning_presence` (
	`student_id` text PRIMARY KEY NOT NULL,
	`last_seen` integer NOT NULL,
	`page` text NOT NULL,
	`hand_raised` integer DEFAULT 0 NOT NULL,
	`hand_note` text DEFAULT '' NOT NULL,
	`raised_at` integer,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `learning_videos` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `notices` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`kind` text NOT NULL,
	`ref` text NOT NULL,
	`message` text NOT NULL,
	`created_at` integer NOT NULL,
	`read_at` integer,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_notice_ref` ON `notices` (`student_id`,`kind`,`ref`);--> statement-breakpoint
CREATE TABLE `subscription_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`price` integer DEFAULT 0 NOT NULL,
	`days` integer DEFAULT 30 NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`phone` text NOT NULL,
	`receipt` text NOT NULL,
	`amount` integer NOT NULL,
	`days` integer NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`verified_at` integer,
	`expires_at` integer,
	`note` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `subscription_receipt` ON `subscriptions` (`receipt`);--> statement-breakpoint
CREATE TABLE `video_credits` (
	`student_id` text PRIMARY KEY NOT NULL,
	`allowance` integer DEFAULT 1200 NOT NULL,
	`used` integer DEFAULT 0 NOT NULL,
	`lease_id` text,
	`lease_expires` integer,
	`granted_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);


-- 0003_swift_trish_tilby.sql
CREATE TABLE `teacher_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`full_name` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`subject` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`user_id` text,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`activated_at` integer,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `teacher_account_email` ON `teacher_accounts` (`email`);

-- 0004_lumpy_edwin_jarvis.sql
CREATE TABLE `call_signals` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`call_id` text NOT NULL,
	`sender_id` text NOT NULL,
	`type` text NOT NULL,
	`payload` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`call_id`) REFERENCES `classroom_calls`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `signals_call_id` ON `call_signals` (`call_id`,`id`);--> statement-breakpoint
CREATE TABLE `cctv_cameras` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`name` text NOT NULL,
	`url` text NOT NULL,
	`format` text NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classroom_rooms`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `classroom_calls` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`student_id` text NOT NULL,
	`teacher_id` text NOT NULL,
	`topic` text NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`created_at` integer NOT NULL,
	`accepted_at` integer,
	`ended_at` integer,
	`last_seen` integer NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classroom_rooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `calls_room_status` ON `classroom_calls` (`room_id`,`status`);--> statement-breakpoint
CREATE TABLE `classroom_rooms` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `learner_access` (
	`student_id` text PRIMARY KEY NOT NULL,
	`login_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`issued_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `learner_login_id` ON `learner_access` (`login_id`);--> statement-breakpoint
CREATE TABLE `virtual_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`experiment` text NOT NULL,
	`inputs` text NOT NULL,
	`results` text NOT NULL,
	`notes` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);


-- 0005_adorable_nebula.sql
CREATE TABLE `payment_access_grants` (
	`payment_id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`granted_at` integer NOT NULL,
	FOREIGN KEY (`payment_id`) REFERENCES `payments`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);


-- 0006_large_quentin_quire.sql
CREATE TABLE `class_attendance` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`student_id` text NOT NULL,
	`joined_at` integer NOT NULL,
	`last_seen` integer NOT NULL,
	`ready` integer DEFAULT 0 NOT NULL,
	`left_at` integer,
	FOREIGN KEY (`session_id`) REFERENCES `class_sessions`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `class_attendance_learner` ON `class_attendance` (`session_id`,`student_id`);--> statement-breakpoint
CREATE TABLE `class_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`title` text NOT NULL,
	`status` text DEFAULT 'preparing' NOT NULL,
	`opens_at` integer NOT NULL,
	`starts_at` integer NOT NULL,
	`ended_at` integer,
	FOREIGN KEY (`room_id`) REFERENCES `classroom_rooms`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `class_sessions_room` ON `class_sessions` (`room_id`,`opens_at`);--> statement-breakpoint
CREATE TABLE `payment_intents` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`phone` text NOT NULL,
	`amount` integer NOT NULL,
	`days` integer NOT NULL,
	`status` text DEFAULT 'starting' NOT NULL,
	`checkout_id` text,
	`merchant_id` text,
	`message` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	`checked_at` integer,
	`confirmed_at` integer,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `payment_intent_checkout` ON `payment_intents` (`checkout_id`);--> statement-breakpoint
CREATE INDEX `payment_intent_student` ON `payment_intents` (`student_id`,`created_at`);

-- 0007_sloppy_gressill.sql
CREATE TABLE `cctv_monitors` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`teacher_id` text NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classroom_rooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `cctv_monitor_room_teacher` ON `cctv_monitors` (`room_id`,`teacher_id`);

-- 0008_omniscient_mandarin.sql
ALTER TABLE `learning_videos` ADD `experiment` text DEFAULT 'general' NOT NULL;--> statement-breakpoint
ALTER TABLE `learning_videos` ADD `explanation` text DEFAULT '' NOT NULL;

-- 0009_greedy_jazinda.sql
ALTER TABLE `class_attendance` ADD `camera_frame` text;--> statement-breakpoint
ALTER TABLE `class_attendance` ADD `camera_at` integer;

-- 0010_six_day_access.sql
-- New subscription purchases use six days. Preserve prices and existing paid grants.
UPDATE subscription_settings SET days=6 WHERE id='main';


-- 0011_open_matthew_murdock.sql
ALTER TABLE `labs` ADD `class_level` text DEFAULT 'all' NOT NULL;--> statement-breakpoint
ALTER TABLE `labs` ADD `topic` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `lessons` ADD `class_level` text DEFAULT 'all' NOT NULL;--> statement-breakpoint
ALTER TABLE `lessons` ADD `topic` text DEFAULT '' NOT NULL;

-- 0012_eager_wither.sql
CREATE TABLE `teaching_outlines` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`class_level` text NOT NULL,
	`subject` text NOT NULL,
	`title` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `teaching_outline_topic` ON `teaching_outlines` (`teacher_id`,`class_level`,`subject`,`title`);

-- 0013_bent_mysterio.sql
CREATE TABLE `lesson_access_events` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`teacher_id` text,
	`resource` text NOT NULL,
	`reason` text NOT NULL,
	`bucket` integer NOT NULL,
	`attempt_count` integer DEFAULT 1 NOT NULL,
	`first_at` integer NOT NULL,
	`last_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`teacher_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `access_event_window` ON `lesson_access_events` (`student_id`,`resource`,`reason`,`bucket`);--> statement-breakpoint
CREATE INDEX `access_event_teacher` ON `lesson_access_events` (`teacher_id`,`last_at`);


-- v18 additive registration/trial/reconciliation migration
-- JEZTECH Learning v18: registration, trial access and payment reconciliation
-- Additive migration. Existing learner and subscription records are preserved.
ALTER TABLE payment_intents ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'tuition';
ALTER TABLE payment_intents ADD COLUMN account_reference TEXT NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS registration_fee_settings (
  id TEXT PRIMARY KEY,
  amount INTEGER NOT NULL DEFAULT 0,
  business_number TEXT NOT NULL DEFAULT '',
  account_reference_prefix TEXT NOT NULL DEFAULT 'REG',
  instructions TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS registration_fee_payments (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES users(id),
  phone TEXT NOT NULL,
  receipt TEXT NOT NULL UNIQUE,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by TEXT REFERENCES users(id),
  review_note TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  reviewed_at INTEGER
);
CREATE INDEX IF NOT EXISTS registration_fee_student
  ON registration_fee_payments(student_id, created_at);

CREATE TABLE IF NOT EXISTS payment_reconciliation_batches (
  id TEXT PRIMARY KEY,
  batch_reference TEXT NOT NULL UNIQUE,
  period_start INTEGER,
  period_end INTEGER,
  total_received INTEGER NOT NULL DEFAULT 0,
  total_matched INTEGER NOT NULL DEFAULT 0,
  total_unmatched INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);

CREATE TABLE IF NOT EXISTS payment_reconciliation_items (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES payment_reconciliation_batches(id),
  payment_type TEXT NOT NULL CHECK(payment_type IN ('registration','tuition')),
  external_reference TEXT NOT NULL,
  student_id TEXT REFERENCES users(id),
  payment_id TEXT,
  expected_amount INTEGER,
  received_amount INTEGER NOT NULL,
  match_status TEXT NOT NULL DEFAULT 'unmatched',
  exception_reason TEXT NOT NULL DEFAULT '',
  reviewed_by TEXT REFERENCES users(id),
  reviewed_at INTEGER,
  created_at INTEGER NOT NULL,
  UNIQUE(batch_id, external_reference)
);

CREATE TABLE IF NOT EXISTS learner_trial_access (
  student_id TEXT PRIMARY KEY REFERENCES users(id),
  starts_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  granted_by TEXT REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS trial_expiry ON learner_trial_access(expires_at);
