# JEZTECH Learning — source code

This is the source snapshot for published version 17, including the Back button.
Live Site: https://jeztech-learning.snugrhino8.chatgpt.site

## Start here

This is a React / TypeScript application with a Vinext frontend, Cloudflare Worker
API, D1 SQLite database and R2 video storage. It is not a standalone HTML page:
opening a file directly will not run the application.

1. Extract this ZIP into a folder, and open that folder in VS Code.
2. Install a Node.js version satisfying package.json (>=22.13.0). The project pins
   pnpm 11.25.0 in package.json. Use the pinned package manager and lockfile.
3. From the project folder in PowerShell or a terminal:

   npm install --global pnpm@11.25.0
   pnpm install --frozen-lockfile

4. Apply the empty-database migrations locally:

   pnpm exec wrangler d1 migrations apply DB --local --config wrangler.local.jsonc

5. Configure local development sign-in as described below, then start:

   pnpm dev

   Open the localhost address printed in the terminal (the portable setup uses 5173).

Dependencies and external services require an internet connection. The archive
contains no node_modules or production build output. WSL/Linux is an alternative
if your Windows installation encounters native dependency problems.

## Local and production sign-in

The production Site uses verified ChatGPT sign-in supplied by Sites hosting; no
custom username/password database is implemented. A different production host
requires a trusted identity integration before deployment. Never treat arbitrary
browser-provided identity headers as verified authentication.

Local-only mock sign-in is implemented in build/sites-vite-plugin.ts and restricted
to loopback development. Its default localEmail is seedy@sites.test. The current
bootstrap administrator email in app/ is jezreelch@gmail.com. For a fresh LOCAL
copy, set the localEmail constant to the bootstrap email before your first login;
or consistently replace the bootstrap email throughout app/ with your own email
and make the local mock match it. This is a development identity, not a password.
Do not use mock authentication as a production identity provider.

## What is included

- app/workspace.tsx: student, teacher and admin dashboards, including Back navigation.
- app/api/: backend routes for learning, payments, classes, videos and automation.
- app/classroom/: camera/microphone calls, preparation board, subscription access
  checks and blocked-access reports.
- app/lab/, app/virtual-lab/: practicals, grading, journals, uploaded video studio
  and three original AI-assisted, captioned animations.
- app/curriculum/: 165 official design viewer links, six source-hosted KEC video
  resources and CSV/TXT topic import. A full syllabus topic/notes import is NOT
  included; imported teacher topics start empty in a new database.
- db/schema.ts and drizzle/: database model and ordered migrations, 0000–0013.
- database/initialize-empty-database.sql: the same migrations combined, for a NEW
  EMPTY SQLite database only. Do not run it on an existing live database.
- tests/: service, access-control and curriculum tests.
- media/: MP4 copies of the three generated animations. The server also embeds
  these in server-only TypeScript payloads behind authenticated playback.
- scripts/content/render-practicals.py: reproducible animation renderer, requiring
  Python with Pillow, ffmpeg and the configured DejaVu font paths.

There are no live learners, receipts, payments, uploaded teacher videos, database
backups, cookies, passwords, API keys or service tokens in this package.

## Checks and build

   node --test tests/service.test.mjs tests/curriculum.test.mjs
   node node_modules/typescript/bin/tsc --noEmit
   pnpm build

95 service/curriculum tests passed before the Back-button-only change; TypeScript
and production build checks passed for this exact source snapshot. Browser
interaction/playback was not tested in this export. These commands require the
installed dependencies; they are not evidence of a separately validated Windows
installation.

## Database and hosting

wrangler.local.jsonc is for LOCAL migration commands only and matches the local
DB/BUCKET binding names in vite.config.ts. Production requires separately
provisioned D1 and R2 resources plus trusted authentication.

.openai/hosting.json retains the identity of the existing JEZTECH Site so this
snapshot represents your project. To create an independent hosted copy, register
new hosting resources and use that copy's new project ID. Do not publish a clone
to the existing project's identity unintentionally.

Apply migrations in filename order. Never edit migrations already applied to a
live database. The complete production database and R2 bucket are not exported.

## Payments and automation configuration

.env.example lists configuration names only. Store real credentials as secrets in
your hosting platform; do not put them in source files or frontend JavaScript.
MPESA_LIVE_ENABLED defaults to false. A real STK prompt needs your authorised
Daraja consumer key, consumer secret, passkey, shortcode and callback URL. The
configured Paybill instructions alone do not establish an API connection.
Payment access must follow a verified payment; do not create fictitious receipts.

The source includes /api/automation. The earlier unattended assistant was paused;
this ZIP does not create or resume a scheduler. Automatic AI tutoring/assessment
writing and on-demand AI video generation are not connected by installing the
source. Teacher lesson prompts can be copied into ChatGPT. The three included
animations are pre-rendered AI-assisted teaching models, silent and captioned,
and require teacher review. They are not KICD-approved resources.

## Editing guide

Change dashboard navigation in app/workspace.tsx, theme styles in app/globals.css,
subject choices in app/teaching/catalog.ts, and lesson tools in app/teaching/desk.tsx.
Add teachers through the admin dashboard and approve learners through admissions.
Subscription access is checked against verified records and expires after the
configured paid period (six days in the current configuration).


## Version 18 upgrade (12 November 2026)

- Added a separate registration-fee ledger and settings, distinct from tuition subscriptions.
- Added registration receipt submission and administrator verification before admission approval.
- Admission approval grants a one-time 24-hour trial; trial expiry does not renew on refresh.
- Added payment reconciliation batch/item tables for statement matching and exception handling.
- Student registration now explains the registration fee as a separate step; admin admission workspace includes a registration receipt verification queue.
- Standardized action button heights and widths and improved small-screen navigation.

### Important payment configuration
Registration Paybill/Till is configured independently in the admin subscription area and is used for direct registration payments with manual statement verification. Tuition continues to use the existing Daraja STK configuration. Do not invent a shortcode: enter only a Safaricom-approved registration Paybill/Till. For automated registration STK prompts, a second Daraja shortcode/credential set and callback route must be provisioned separately.

Apply the new migration after taking a production D1 backup: `pnpm exec wrangler d1 migrations apply DB --remote`. Do not run the empty-database SQL against an existing live database.
