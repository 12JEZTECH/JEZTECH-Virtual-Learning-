'use client';
import {useState} from 'react';
export default function FreeAccessAdmin(){
 const [studentId,setStudentId]=useState(''),[hours,setHours]=useState(24),[reason,setReason]=useState('Free lesson invitation'),[message,setMessage]=useState(''),[busy,setBusy]=useState(false);
 async function grant(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage('');try{
 const r=await fetch('/api/admin/free-access',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({studentId,hours,reason})});
 const v=await r.json() as {error?:string;expiresAt?:number};if(!r.ok)throw new Error(v.error||'Could not grant access');
 setMessage('Free access granted until '+new Date(v.expiresAt!).toLocaleString());
 }catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 return <section className="panel"><h2>Invite learners · Free lesson access</h2><p>Grant an approved learner access to eligible lessons for a chosen period. This does not create a payment or extend tuition.</p>
 <form onSubmit={grant}><label>Student user ID<input value={studentId} onChange={e=>setStudentId(e.target.value)} required/></label>
 <label>Free access duration<select value={hours} onChange={e=>setHours(Number(e.target.value))}><option value={1}>1 hour</option><option value={6}>6 hours</option><option value={24}>24 hours</option><option value={72}>3 days</option><option value={168}>7 days</option><option value={720}>30 days</option></select></label>
 <label>Invitation note<input value={reason} onChange={e=>setReason(e.target.value)} maxLength={300}/></label>
 <button disabled={busy}>{busy?'Granting…':'Grant free lesson access'}</button></form>{message&&<p role="status">{message}</p>}</section>;
}
