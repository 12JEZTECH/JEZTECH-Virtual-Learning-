import {requireChatGPTUser} from '../../chatgpt-auth';
import FreeAccessAdmin from '../free-access';
export default async function Page(){await requireChatGPTUser('/admin/free-lessons');return <main style={{maxWidth:760,margin:'30px auto',padding:20}}><a href='/admin'>← Admin dashboard</a><FreeAccessAdmin/></main>}
