import {z} from 'zod';
import {AppError,type User} from '../service';
const st=(db:D1Database,sql:string,...v:unknown[])=>db.prepare(sql).bind(...v);
const one=(db:D1Database,sql:string,...v:unknown[])=>st(db,sql,...v).first<any>();
export const portalPath=(role:string)=>role==='admin'?'/admin':role==='teacher'?'/teacher':'/student';
export const PortalActionSchema=z.discriminatedUnion('action',[
 z.object({action:z.literal('addTeacher'),fullName:z.string().trim().min(2).max(160),email:z.string().trim().email().max(254),phone:z.string().trim().max(25).default(''),subject:z.string().trim().max(160).default('')}),
 z.object({action:z.literal('teacherAccountStatus'),id:z.string().uuid(),enabled:z.boolean()}),
]);
export async function readPortalAccounts(db:D1Database,u:User){
 if(u.role!=='admin')return {teacherAccounts:[]};
 return {teacherAccounts:(await st(db,'SELECT t.*,u.disabled AS account_disabled FROM teacher_accounts t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC').all()).results};
}
export async function mutatePortal(db:D1Database,u:User,a:z.infer<typeof PortalActionSchema>,now=Date.now()){
 if(u.role!=='admin')throw new AppError(403,'Only administrators can add or manage teacher accounts');
 if(a.action==='addTeacher'){
 const email=a.email.toLowerCase().trim();if(email===u.email.toLowerCase())throw new AppError(409,'Your administrator account is already registered');
 if(await one(db,'SELECT id FROM teacher_accounts WHERE email=?',email))throw new AppError(409,'This teacher is already registered. Manage their access in the list below.');
 const existing=await one(db,'SELECT * FROM users WHERE lower(email)=?',email);if(existing?.role==='admin')throw new AppError(409,'Administrator accounts cannot be changed into teachers');if(existing?.disabled)throw new AppError(409,'This account is disabled. Enable it under People & access before adding it as a teacher.');
 const id=crypto.randomUUID();const actions=[st(db,'INSERT INTO teacher_accounts(id,email,full_name,phone,subject,status,user_id,created_by,created_at,activated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',id,email,a.fullName,a.phone,a.subject,existing?'active':'pending',existing?.id||null,u.id,now,existing?now:null)];
 if(existing)actions.push(st(db,"UPDATE users SET role='teacher',name=? WHERE id=? AND role!='admin' AND disabled=0",a.fullName,existing.id));
 await db.batch(actions);return {ok:true,id,status:existing?'active':'pending'};
 }
 const row=await one(db,'SELECT * FROM teacher_accounts WHERE id=?',a.id);if(!row)throw new AppError(404,'Teacher account not found');
 if(row.user_id){const linked=await one(db,'SELECT role FROM users WHERE id=?',row.user_id);if(linked?.role==='admin')throw new AppError(409,'Administrator accounts are protected')}
 const actions=[st(db,'UPDATE teacher_accounts SET status=? WHERE id=?',a.enabled?(row.user_id?'active':'pending'):'revoked',row.id)];
 if(row.user_id)actions.push(st(db,"UPDATE users SET disabled=?,role=? WHERE id=? AND role!='admin'",a.enabled?0:1,a.enabled?'teacher':'student',row.user_id));
 await db.batch(actions);return {ok:true};
}
