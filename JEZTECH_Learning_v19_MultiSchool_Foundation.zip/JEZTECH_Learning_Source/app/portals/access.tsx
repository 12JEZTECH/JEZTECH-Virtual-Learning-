import {env} from 'cloudflare:workers';
import {redirect} from 'next/navigation';
import {requireChatGPTUser} from '../chatgpt-auth';
import {initializeUser} from '../service';
import {requirePaidAccess} from '../classroom/access';
import {AppError} from '../service';
import Workspace from '../workspace';
export default async function Portal({role}:{role:'admin'|'teacher'|'student'}){
 const identity=await requireChatGPTUser('/'+role);if(!env.DB)throw new Error('Learning database unavailable');const user=await initializeUser(env.DB,identity,'jezreelch@gmail.com');
 if(user.role!==role)redirect('/login/'+role+'?mismatch=1');
 if(role==='student'&&!await env.DB.prepare("SELECT student_id FROM admissions WHERE student_id=? AND status='approved'").bind(user.id).first())redirect('/register');
 if(role==='student')try{await requirePaidAccess(env.DB,user)}catch(e){if(e instanceof AppError&&e.status===402)redirect('/activate');throw e}
 return <Workspace portal={role}/>;
}
