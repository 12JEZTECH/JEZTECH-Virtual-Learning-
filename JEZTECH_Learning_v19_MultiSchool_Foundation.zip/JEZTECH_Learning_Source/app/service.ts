import { z } from 'zod';

export type User = {id:string;email:string;name:string;role:'admin'|'teacher'|'student';disabled:number};
export class AppError extends Error { constructor(public status:number,message:string){super(message)} }
const uuid=z.string().uuid();
const question=z.object({text:z.string().trim().min(1).max(2000),choices:z.array(z.string().trim().min(1).max(500)).length(4),correct:z.number().int().min(0).max(3)});
export const ActionSchema=z.discriminatedUnion('action',[
 z.object({action:z.literal('createExam'),title:z.string().trim().min(1).max(160),description:z.string().trim().max(3000).default(''),duration:z.number().int().min(1).max(300),startsAt:z.number().int().positive().nullable().default(null),endsAt:z.number().int().positive().nullable().default(null),questions:z.array(question).min(1).max(100)}),
 z.object({action:z.literal('addQuestion'),examId:uuid,question}),
 z.object({action:z.literal('examStatus'),examId:uuid,status:z.enum(['published','closed'])}),
 z.object({action:z.literal('start'),examId:uuid}),
 z.object({action:z.literal('answer'),sessionId:uuid,position:z.number().int().min(0).max(99),choice:z.number().int().min(0).max(3)}),
 z.object({action:z.literal('submit'),sessionId:uuid}),
 z.object({action:z.literal('heartbeat'),sessionId:uuid}),
 z.object({action:z.literal('event'),sessionId:uuid,code:z.enum(['tab_switch','window_blur','copy_paste','fullscreen_exit','no_face','multiple_faces','off_center']),}),
 z.object({action:z.literal('teacherAction'),sessionId:uuid,kind:z.enum(['warn','pause','resume','terminate','dismiss_flag']),message:z.string().trim().max(500).default('')}),
 z.object({action:z.literal('userRole'),userId:z.string().min(1).max(200),role:z.enum(['student','teacher']),disabled:z.boolean()}),
]);
export type Action=z.infer<typeof ActionSchema>;
const stmt=(db:D1Database,sql:string,...values:unknown[])=>db.prepare(sql).bind(...values);
async function all(db:D1Database,sql:string,...values:unknown[]){return (await stmt(db,sql,...values).all<any>()).results}
async function one(db:D1Database,sql:string,...values:unknown[]){return stmt(db,sql,...values).first<any>()}
function required<T>(value:T|null,message='Record not found'):T {if(!value)throw new AppError(404,message);return value}
function staff(u:User){if(u.role==='student')throw new AppError(403,'Teacher access required')}
async function ownedExam(db:D1Database,u:User,id:string){staff(u);let e=required(await one(db,'SELECT * FROM exams WHERE id=?',id));if(u.role!=='admin'&&e.teacher_id!==u.id)throw new AppError(403,'This exam belongs to another teacher');return e}
async function ownSession(db:D1Database,u:User,id:string){let s=required(await one(db,'SELECT * FROM sessions WHERE id=?',id));if(s.student_id!==u.id)throw new AppError(403,'This session belongs to another student');return s}
const scoreSQL=`(SELECT COUNT(*) FROM questions q WHERE q.exam_id=sessions.exam_id AND CAST(json_extract(sessions.answers,'$."'||q.position||'"') AS INTEGER)=q.correct)`;
export async function expireSessions(db:D1Database,now:number){await stmt(db,`UPDATE sessions SET status='submitted',score=${scoreSQL},ended_at=? WHERE (status='active' AND deadline<=?) OR (status='paused' AND EXISTS(SELECT 1 FROM exams e WHERE e.id=sessions.exam_id AND e.ends_at IS NOT NULL AND e.ends_at<=?))`,now,now,now).run()}
export async function initializeUser(db:D1Database,identity:{userId:string;email:string;displayName:string},ownerEmail:string,now=Date.now()):Promise<User>{
 await stmt(db,'INSERT INTO users(id,email,name,role,created_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING',identity.userId,identity.email,identity.displayName,identity.email.toLowerCase()===ownerEmail.toLowerCase()?'admin':'student',now).run();
 let u=required(await one(db,'SELECT * FROM users WHERE id=?',identity.userId));
 if(u.disabled)throw new AppError(403,'Your account has been disabled. Contact your administrator.');
 const teacher=await one(db,"SELECT * FROM teacher_accounts WHERE email=? AND status='pending'",identity.email.trim().toLowerCase());
 if(teacher&&u.role!=='admin'){
 await db.batch([
 stmt(db,"UPDATE users SET role='teacher',name=? WHERE id=? AND disabled=0 AND role!='admin' AND EXISTS(SELECT 1 FROM teacher_accounts WHERE id=? AND status='pending')",teacher.full_name,u.id,teacher.id),
 stmt(db,"UPDATE teacher_accounts SET status='active',user_id=?,activated_at=? WHERE id=? AND status='pending'",u.id,now,teacher.id)]);
 u=required(await one(db,'SELECT * FROM users WHERE id=?',identity.userId));
 }
 return u;
}
export async function readState(db:D1Database,u:User,now=Date.now()){
 await expireSessions(db,now);
 const student=u.role==='student';
 const examWhere=student?"(e.status='published' OR EXISTS(SELECT 1 FROM sessions s WHERE s.exam_id=e.id AND s.student_id=?)) AND (NOT EXISTS(SELECT 1 FROM assessment_cycles c WHERE c.exam_id=e.id) OR EXISTS(SELECT 1 FROM assessment_cycles c WHERE c.exam_id=e.id AND c.student_id=?))":u.role==='teacher'?'e.teacher_id=?':'1=1';
 const values=student?[u.id,u.id]:u.role==='teacher'?[u.id]:[];
 let exams=await all(db,`SELECT e.*,us.name AS teacher_name FROM exams e JOIN users us ON us.id=e.teacher_id WHERE ${examWhere} ORDER BY e.created_at DESC`,...values);
 // Answers are never sent to student clients, including after submission.
 const qs=await all(db,`SELECT q.id,q.exam_id,q.position,q.text,q.choices ${student?'':',q.correct'} FROM questions q JOIN exams e ON e.id=q.exam_id WHERE ${examWhere} ORDER BY q.position`,...values);
 exams=exams.map(e=>({...e,questions:qs.filter(q=>q.exam_id===e.id).map(q=>({...q,choices:JSON.parse(q.choices)}))}));
 const scope=student?'s.student_id=?':u.role==='teacher'?'e.teacher_id=?':'1=1';
 const sessions=await all(db,`SELECT s.*,us.name AS student_name,e.title AS exam_title FROM sessions s JOIN exams e ON e.id=s.exam_id JOIN users us ON us.id=s.student_id WHERE ${scope} ORDER BY s.started_at DESC`,...(student||u.role==='teacher'?[u.id]:[]));
 const events=await all(db,`SELECT v.*,us.name AS student_name,e.title AS exam_title FROM events v JOIN sessions s ON s.id=v.session_id JOIN exams e ON e.id=s.exam_id JOIN users us ON us.id=s.student_id WHERE ${scope} ORDER BY v.at DESC LIMIT 200`,...(student||u.role==='teacher'?[u.id]:[]));
 return {user:u,exams,sessions:sessions.map(s=>({...s,answers:student?JSON.parse(s.answers):undefined})),events,users:u.role==='admin'?await all(db,'SELECT * FROM users ORDER BY created_at DESC'):[],serverNow:now};
}
export async function mutate(db:D1Database,u:User,a:Action,now=Date.now()):Promise<any>{
 await expireSessions(db,now);
 if(a.action==='createExam'){
  staff(u);if(a.startsAt&&a.endsAt&&a.endsAt<=a.startsAt)throw new AppError(400,'Closing time must be later than opening time');if(a.endsAt&&a.endsAt<=now)throw new AppError(400,'Closing time must be in the future');
  const id=crypto.randomUUID();await db.batch([stmt(db,'INSERT INTO exams(id,teacher_id,title,description,duration,starts_at,ends_at,created_at) VALUES(?,?,?,?,?,?,?,?)',id,u.id,a.title,a.description,a.duration,a.startsAt,a.endsAt,now),...a.questions.map((q,i)=>stmt(db,'INSERT INTO questions(id,exam_id,position,text,choices,correct) VALUES(?,?,?,?,?,?)',crypto.randomUUID(),id,i,q.text,JSON.stringify(q.choices),q.correct))]);return {id};
 }
 if(a.action==='addQuestion'){
  const e=await ownedExam(db,u,a.examId);if(e.status!=='draft')throw new AppError(409,'Only draft exams can be edited');
  const q=a.question;const result=await stmt(db,`INSERT INTO questions(id,exam_id,position,text,choices,correct) SELECT ?,?,(SELECT COUNT(*) FROM questions WHERE exam_id=?),?,?,? WHERE EXISTS(SELECT 1 FROM exams WHERE id=? AND status='draft') AND (SELECT COUNT(*) FROM questions WHERE exam_id=?)<100`,crypto.randomUUID(),e.id,e.id,q.text,JSON.stringify(q.choices),q.correct,e.id,e.id).run();if(!result.meta.changes)throw new AppError(409,'Exam is published or has reached 100 questions');return {ok:true};
 }
 if(a.action==='examStatus'){
  const e=await ownedExam(db,u,a.examId);if(a.status==='published'&&e.status!=='draft')throw new AppError(409,'Only draft exams may be published');
  if(a.status==='closed'&&e.status!=='published')throw new AppError(409,'Only published exams may be closed');
  await stmt(db,'UPDATE exams SET status=? WHERE id=? AND status=?',a.status,e.id,e.status).run();return {ok:true};
 }
 if(a.action==='userRole'){
  if(u.role!=='admin')throw new AppError(403,'Administrator access required');const target=required(await one(db,'SELECT * FROM users WHERE id=?',a.userId));if(target.role==='admin')throw new AppError(400,'Administrator accounts cannot be changed here');
  await stmt(db,'UPDATE users SET role=?,disabled=? WHERE id=? AND role!=?',a.role,a.disabled?1:0,a.userId,'admin').run();return {ok:true};
 }
 if(a.action==='start'){
  if(u.role!=='student')throw new AppError(403,'Only student accounts may take exams');const e=required(await one(db,'SELECT * FROM exams WHERE id=?',a.examId));
  if(await one(db,'SELECT id FROM assessment_cycles WHERE exam_id=? AND student_id!=?',e.id,u.id))throw new AppError(403,'This assessment is assigned to another learner');
  const previous=await one(db,'SELECT id FROM sessions WHERE exam_id=? AND student_id=?',e.id,u.id);if(previous)return {id:previous.id};
  if(e.status!=='published'||(e.starts_at&&now<e.starts_at)||(e.ends_at&&now>=e.ends_at))throw new AppError(409,'This exam is not open');
  const total=(await one(db,'SELECT COUNT(*) AS n FROM questions WHERE exam_id=?',e.id)).n;if(!total)throw new AppError(409,'Exam has no questions');
  const id=crypto.randomUUID(),deadline=Math.min(now+e.duration*60000,e.ends_at||Infinity);
  const insert=stmt(db,`INSERT INTO sessions(id,exam_id,student_id,started_at,deadline,last_seen,total) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM exams WHERE id=? AND status='published' AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>?)) ON CONFLICT(exam_id,student_id) DO NOTHING`,id,e.id,u.id,now,deadline,now,total,e.id,now,now);
  await db.batch([insert,stmt(db,`INSERT INTO events(id,session_id,actor_id,code,message,at) SELECT ?,?,?, 'started','Assessment started',? WHERE EXISTS(SELECT 1 FROM sessions WHERE id=?)`,crypto.randomUUID(),id,u.id,now,id)]);
  const saved=required(await one(db,'SELECT id FROM sessions WHERE exam_id=? AND student_id=?',e.id,u.id),'Exam closed before the session began');return {id:saved.id};
 }
 if(a.action==='teacherAction'){
  const s=required(await one(db,'SELECT * FROM sessions WHERE id=?',a.sessionId));const e=await ownedExam(db,u,s.exam_id);if(!['active','paused'].includes(s.status))throw new AppError(409,'This session has already ended');
  let update='',values:unknown[]=[];
  if(a.kind==='warn')update='warnings=warnings+1,flagged=1';
  if(a.kind==='dismiss_flag')update='flagged=0';
  if(a.kind==='terminate'){update="status='terminated',ended_at=?,flagged=1";values=[now]}
  if(a.kind==='pause'){if(s.status!=='active')throw new AppError(409,'Session is already paused');update="status='paused',remaining_ms=MAX(0,deadline-?)";values=[now]}
  if(a.kind==='resume'){if(s.status!=='paused')throw new AppError(409,'Session is not paused');if(e.ends_at&&now>=e.ends_at)throw new AppError(409,'The exam closing time has passed; terminate this session');update="status='active',deadline=MIN(?+remaining_ms,?),remaining_ms=NULL";values=[now,e.ends_at||Number.MAX_SAFE_INTEGER]}
  const message=a.message||({warn:'Teacher warning: please focus on the assessment.',pause:'Teacher paused the assessment.',resume:'Teacher resumed the assessment.',terminate:'Teacher ended the session.',dismiss_flag:'Teacher reviewed and dismissed the flag.'}[a.kind]);
  // D1 batch is atomic. The audit entry and action share the same state predicate.
  const result=await db.batch([stmt(db,`INSERT INTO events(id,session_id,actor_id,code,message,at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sessions WHERE id=? AND status=?)`,crypto.randomUUID(),s.id,u.id,a.kind,message,now,s.id,s.status),stmt(db,`UPDATE sessions SET ${update} WHERE id=? AND status=?`,...values,s.id,s.status)]);if(!result[1].meta.changes)throw new AppError(409,'Session changed; refresh and try again');return {ok:true};
 }
 const s=await ownSession(db,u,a.sessionId);
 if(a.action==='heartbeat'){await stmt(db,"UPDATE sessions SET last_seen=? WHERE id=? AND status IN ('active','paused')",now,s.id).run();return {ok:true}}
 if(a.action==='submit'){
  if(s.status!=='active')throw new AppError(409,'Only active sessions may be submitted');
  await db.batch([stmt(db,`INSERT INTO events(id,session_id,actor_id,code,message,at) SELECT ?,?,?, 'submitted','Student submitted assessment',? WHERE EXISTS(SELECT 1 FROM sessions WHERE id=? AND status='active')`,crypto.randomUUID(),s.id,u.id,now,s.id),stmt(db,`UPDATE sessions SET status='submitted',score=${scoreSQL},ended_at=? WHERE id=? AND status='active'`,now,s.id)]);return {ok:true};
 }
 if(s.status!=='active')throw new AppError(409,'This assessment is paused or finished');
 if(a.action==='answer'){
  const q=await one(db,'SELECT id FROM questions WHERE exam_id=? AND position=?',s.exam_id,a.position);if(!q)throw new AppError(400,'Invalid question');
  const result=await stmt(db,`UPDATE sessions SET answers=json_set(answers,?,?),last_seen=? WHERE id=? AND status='active' AND deadline>?`, '$."'+a.position+'"',a.choice,now,s.id,now).run();if(!result.meta.changes)throw new AppError(409,'Time has expired or the session is no longer active');return {ok:true};
 }
 if(a.action==='event'){
  const labels={tab_switch:'Browser tab became hidden',window_blur:'Exam window lost focus',copy_paste:'Copy or paste observed',fullscreen_exit:'Exited fullscreen',no_face:'Local camera check reported no face',multiple_faces:'Local camera check reported multiple faces',off_center:'Local camera check reported a face outside the centre'};
  const id=crypto.randomUUID();await db.batch([stmt(db,`INSERT INTO events(id,session_id,actor_id,code,message,at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sessions WHERE id=? AND status='active') AND NOT EXISTS(SELECT 1 FROM events WHERE session_id=? AND code=? AND at>?)`,id,s.id,u.id,a.code,labels[a.code],now,s.id,s.id,a.code,now-3000),stmt(db,`UPDATE sessions SET flagged=1 WHERE id=? AND EXISTS(SELECT 1 FROM events WHERE id=?)`,s.id,id)]);return {ok:true};
 }
 throw new AppError(400,'Unknown action');
}
