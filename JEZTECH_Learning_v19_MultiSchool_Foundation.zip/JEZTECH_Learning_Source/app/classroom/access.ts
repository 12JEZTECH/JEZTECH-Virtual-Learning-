import {AppError,type User} from '../service';
const st=(db:D1Database,sql:string,...v:unknown[])=>db.prepare(sql).bind(...v);
export async function refreshAccess(db:D1Database,id:string,now=Date.now()){
 const plan=await st(db,"SELECT days FROM subscription_settings WHERE id='main'").first<{days:number}>();const days=plan?.days||6;
 const sub=await st(db,"SELECT MAX(expires_at) AS until FROM subscriptions WHERE student_id=? AND status='verified'",id).first<{until:number|null}>();
 const paid=(await st(db,"SELECT id,COALESCE(reviewed_at,created_at) AS at FROM payments WHERE student_id=? AND status='verified'",id).all<{id:string;at:number}>()).results;
 for(const p of paid)await st(db,'INSERT INTO payment_access_grants(payment_id,student_id,expires_at,granted_at) VALUES(?,?,?,?) ON CONFLICT(payment_id) DO NOTHING',p.id,id,p.at+days*86400000,now).run();
 const grant=await st(db,"SELECT MAX(g.expires_at) AS until FROM payment_access_grants g JOIN payments p ON p.id=g.payment_id WHERE g.student_id=? AND p.status='verified'",id).first<{until:number|null}>();
 const trial=await st(db,"SELECT expires_at FROM learner_trial_access WHERE student_id=?",id).first<{expires_at:number}>();
 const until=Math.max(sub?.until||0,grant?.until||0,trial?.expires_at||0);
 if(until){const loginId='JZT-'+crypto.randomUUID().replace(/-/g,'').slice(0,12).toUpperCase();await st(db,'INSERT INTO learner_access(student_id,login_id,expires_at,issued_at) VALUES(?,?,?,?) ON CONFLICT(student_id) DO UPDATE SET expires_at=excluded.expires_at',id,loginId,until,now).run()}
 if(!until)await st(db,'UPDATE learner_access SET expires_at=0 WHERE student_id=?',id).run();
 return st(db,'SELECT * FROM learner_access WHERE student_id=?',id).first<any>();
}
export async function requirePaidAccess(db:D1Database,u:User,now=Date.now(),resource='protected_lesson'){
 if(u.role!=='student')return null;
 if(u.disabled){await recordAccessBlock(db,u,'account_disabled',resource,now);await closeUnpaidSessions(db,u.id,now);throw new AppError(403,'This learner account is disabled')}
 if(!await st(db,"SELECT student_id FROM admissions WHERE student_id=? AND status='approved'",u.id).first()){await recordAccessBlock(db,u,'admission_required',resource,now);await closeUnpaidSessions(db,u.id,now);throw new AppError(403,'Admission approval is required')}
 const access=await refreshAccess(db,u.id,now);
 if(!access||access.expires_at<=now){await recordAccessBlock(db,u,'subscription_inactive',resource,now);await closeUnpaidSessions(db,u.id,now);throw new AppError(402,'Your learner login requires a verified payment or renewal. Open Activate access.')}
 return access;
}
export async function accessState(db:D1Database,u:User,now=Date.now()){
 const admission=await st(db,'SELECT status,note FROM admissions WHERE student_id=?',u.id).first<any>();
 const access=await refreshAccess(db,u.id,now);const trial=await st(db,'SELECT starts_at,expires_at FROM learner_trial_access WHERE student_id=?',u.id).first<any>();return {user:{name:u.name,email:u.email,role:u.role},admission,trial,access,active:!!access&&access.expires_at>now,plan:await st(db,"SELECT price,days FROM subscription_settings WHERE id='main'").first(),paymentInstructions:await st(db,"SELECT business_number,account_reference,instructions FROM payment_settings WHERE id='main'").first(),receipts:(await st(db,'SELECT id,receipt,amount,days,status,note,expires_at FROM subscriptions WHERE student_id=? ORDER BY created_at DESC',u.id).all()).results,serverNow:now};
}
export async function verifyLoginId(db:D1Database,u:User,loginId:string,now=Date.now()){
 const access=await requirePaidAccess(db,u,now);if(!access||access.login_id!==loginId.trim().toUpperCase())throw new AppError(403,'This login ID does not belong to your verified account');return {ok:true,dashboard:'/student',expiresAt:access.expires_at};
}

export async function recordAccessBlock(db:D1Database,u:User,reason:string,resource:string,now=Date.now(),teacherId?:string){
 if(u.role!=='student')return;const admission=await st(db,'SELECT teacher_id FROM admissions WHERE student_id=?',u.id).first<{teacher_id:string}>();
 await st(db,`INSERT INTO lesson_access_events(id,student_id,teacher_id,resource,reason,bucket,attempt_count,first_at,last_at) VALUES(?,?,?,?,?,?,1,?,?) ON CONFLICT(student_id,resource,reason,bucket) DO UPDATE SET attempt_count=attempt_count+1,last_at=excluded.last_at`,crypto.randomUUID(),u.id,teacherId||admission?.teacher_id||null,resource.slice(0,80),reason,Math.floor(now/300000),now,now).run();
}
async function closeUnpaidSessions(db:D1Database,studentId:string,now:number,teacherId?:string){await db.batch([
 st(db,`UPDATE class_attendance SET left_at=?,ready=0,camera_frame=NULL,camera_at=NULL WHERE student_id=? AND left_at IS NULL ${teacherId?'AND EXISTS(SELECT 1 FROM class_sessions c JOIN classroom_rooms r ON r.id=c.room_id WHERE c.id=class_attendance.session_id AND r.teacher_id=?)':''}`,now,studentId,...(teacherId?[teacherId]:[])),
 st(db,`UPDATE classroom_calls SET status='ended',ended_at=? WHERE student_id=? AND status IN ('waiting','accepted') ${teacherId?'AND teacher_id=?':''}`,now,studentId,...(teacherId?[teacherId]:[])),
 st(db,`DELETE FROM call_signals WHERE call_id IN (SELECT id FROM classroom_calls WHERE student_id=? AND status='ended' ${teacherId?'AND teacher_id=?':''})`,studentId,...(teacherId?[teacherId]:[])),
 ]);}
export async function sweepUnpaidSessions(db:D1Database,u:User,now=Date.now()){
 if(u.role==='student')return;
 const candidates=(await st(db,`SELECT DISTINCT us.*,r.teacher_id AS owner_id FROM class_attendance a JOIN class_sessions c ON c.id=a.session_id JOIN classroom_rooms r ON r.id=c.room_id JOIN users us ON us.id=a.student_id WHERE a.left_at IS NULL AND c.status!='ended' AND ${u.role==='admin'?'1=1':'r.teacher_id=?'} UNION SELECT DISTINCT us.*,c.teacher_id AS owner_id FROM classroom_calls c JOIN users us ON us.id=c.student_id WHERE c.status IN ('waiting','accepted') AND ${u.role==='admin'?'1=1':'c.teacher_id=?'}`,...(u.role==='admin'?[]:[u.id,u.id])).all<User&{owner_id:string}>()).results;
 for(const learner of candidates){const admission=await st(db,"SELECT teacher_id FROM admissions WHERE student_id=? AND status='approved'",learner.id).first<{teacher_id:string}>();const access=await refreshAccess(db,learner.id,now);
  if(learner.disabled||!admission||admission.teacher_id!==learner.owner_id||!access||access.expires_at<=now){await recordAccessBlock(db,learner,learner.disabled?'account_disabled':!admission||admission.teacher_id!==learner.owner_id?'admission_required':'subscription_inactive','active_class_removed',now,learner.owner_id);await closeUnpaidSessions(db,learner.id,now,learner.owner_id)}
 }
}
export async function readAccessAlerts(db:D1Database,u:User,now=Date.now()){
 if(u.role==='student')return [];
 await sweepUnpaidSessions(db,u,now);await st(db,'DELETE FROM lesson_access_events WHERE last_at<?',now-30*86400000).run();
 return (await st(db,`SELECT e.*,us.name AS student_name,CASE WHEN EXISTS(SELECT 1 FROM subscriptions s WHERE s.student_id=us.id AND s.status='verified' AND s.expires_at>?) OR EXISTS(SELECT 1 FROM payment_access_grants g JOIN payments p ON p.id=g.payment_id WHERE g.student_id=us.id AND p.status='verified' AND g.expires_at>?) THEN 1 ELSE 0 END AS paid_now FROM lesson_access_events e JOIN users us ON us.id=e.student_id WHERE ${u.role==='admin'?'1=1':'e.teacher_id=?'} ORDER BY e.last_at DESC LIMIT 200`,now,now,...(u.role==='admin'?[]:[u.id])).all()).results;
}
