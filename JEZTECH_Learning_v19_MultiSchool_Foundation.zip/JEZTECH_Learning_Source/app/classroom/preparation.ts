import {z} from 'zod';
import {AppError,type User} from '../service';
import {requirePaidAccess,sweepUnpaidSessions} from './access';
import {roomAccess} from './service';
export const PreparationAction=z.discriminatedUnion('action',[
 z.object({action:z.literal('openPreparation'),roomId:z.string().uuid(),title:z.string().trim().min(2).max(160)}),
 z.object({action:z.literal('endClass'),sessionId:z.string().uuid()}),
 z.object({action:z.literal('joinClass'),sessionId:z.string().uuid()}),
 z.object({action:z.literal('classHeartbeat'),sessionId:z.string().uuid()}),
 z.object({action:z.literal('classReady'),sessionId:z.string().uuid(),ready:z.boolean()}),
 z.object({action:z.literal('leaveClass'),sessionId:z.string().uuid()}),
 z.object({action:z.literal('cameraCheckIn'),sessionId:z.string().uuid(),frame:z.string().max(30000).regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/).nullable()}),
]);
const st=(db:D1Database,sql:string,...v:unknown[])=>db.prepare(sql).bind(...v);
async function sessionAccess(db:D1Database,u:User,id:string){const s=await st(db,'SELECT * FROM class_sessions WHERE id=?',id).first<any>();if(!s)throw new AppError(404,'Class session not found');await roomAccess(db,u,s.room_id);return s}
export async function mutatePreparation(db:D1Database,u:User,a:z.infer<typeof PreparationAction>,now=Date.now()){
 await requirePaidAccess(db,u,now,'classroom_join_or_presence');
 if(a.action==='openPreparation'){
  if(u.role==='student')throw new AppError(403,'Teacher access required');await roomAccess(db,u,a.roomId);
  if(await st(db,"SELECT id FROM class_sessions WHERE room_id=? AND status!='ended'",a.roomId).first())throw new AppError(409,'End the current class before opening another');
  const id=crypto.randomUUID();try{const created=await st(db,"INSERT INTO class_sessions(id,room_id,title,opens_at,starts_at) SELECT ?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM class_sessions WHERE room_id=? AND status!='ended')",id,a.roomId,a.title,now,now+600000,a.roomId).run();if(!created.meta.changes)throw new Error('Class already open')}catch{throw new AppError(409,'A class is already open for this room')};return {id,startsAt:now+600000};
 }
 const s=await sessionAccess(db,u,a.sessionId);
 if(a.action==='endClass'){if(u.role==='student')throw new AppError(403,'Teacher access required');await db.batch([st(db,"UPDATE class_sessions SET status='ended',ended_at=? WHERE id=?",now,s.id),st(db,'UPDATE class_attendance SET camera_frame=NULL,camera_at=NULL WHERE session_id=?',s.id)]);return {ok:true}}
 if(s.status==='ended')throw new AppError(409,'This class has ended');if(u.role!=='student')throw new AppError(403,'Learner account required');
 if(a.action==='joinClass'){
  if(await st(db,"SELECT a.id FROM class_attendance a JOIN class_sessions c ON c.id=a.session_id WHERE a.student_id=? AND a.session_id!=? AND c.status!='ended' AND a.left_at IS NULL AND a.last_seen>?",u.id,s.id,now-75000).first())throw new AppError(409,'Leave your current class before joining another');
  await st(db,'INSERT INTO class_attendance(id,session_id,student_id,joined_at,last_seen) VALUES(?,?,?,?,?) ON CONFLICT(session_id,student_id) DO UPDATE SET last_seen=excluded.last_seen,left_at=NULL',crypto.randomUUID(),s.id,u.id,now,now).run();return {ok:true};
 }
 const attending=await st(db,'SELECT id FROM class_attendance WHERE session_id=? AND student_id=? AND left_at IS NULL',s.id,u.id).first();if(!attending)throw new AppError(409,'Join the preparation room first');
 if(a.action==='cameraCheckIn'){await st(db,'UPDATE class_attendance SET camera_frame=?,camera_at=?,last_seen=? WHERE session_id=? AND student_id=?',a.frame,a.frame?now:null,now,s.id,u.id).run();return {ok:true}}
 if(a.action==='leaveClass')await st(db,'UPDATE class_attendance SET left_at=?,ready=0,camera_frame=NULL,camera_at=NULL WHERE session_id=? AND student_id=?',now,s.id,u.id).run();
 else if(a.action==='classReady')await st(db,'UPDATE class_attendance SET ready=?,last_seen=? WHERE session_id=? AND student_id=?',a.ready?1:0,now,s.id,u.id).run();
 else await st(db,'UPDATE class_attendance SET last_seen=? WHERE session_id=? AND student_id=?',now,s.id,u.id).run();return {ok:true};
}
export async function readPreparation(db:D1Database,u:User,now=Date.now()){
 await requirePaidAccess(db,u,now,'classroom_board');await sweepUnpaidSessions(db,u,now);await clearExpiredCameraFrames(db,now);await st(db,"UPDATE class_sessions SET status='live' WHERE status='preparing' AND starts_at<=?",now).run();
 const scope=u.role==='admin'?'1=1':u.role==='teacher'?'r.teacher_id=?':"EXISTS(SELECT 1 FROM admissions a WHERE a.student_id=? AND a.teacher_id=r.teacher_id AND a.status='approved')";
 const sessions=(await st(db,`SELECT c.*,r.name AS room_name,r.teacher_id FROM class_sessions c JOIN classroom_rooms r ON r.id=c.room_id WHERE c.status!='ended' AND ${scope} ORDER BY c.opens_at DESC LIMIT 30`,...(u.role==='admin'?[]:[u.id])).all<any>()).results;
 for(const s of sessions){s.roster=(await st(db,`SELECT u.id AS student_id,u.name,a.camera_frame,a.camera_at,a.joined_at,a.last_seen,a.ready,a.left_at,CASE WHEN la.expires_at>? THEN 1 ELSE 0 END AS paid FROM admissions d JOIN users u ON u.id=d.student_id LEFT JOIN class_attendance a ON a.student_id=u.id AND a.session_id=? LEFT JOIN learner_access la ON la.student_id=u.id WHERE d.teacher_id=? AND d.status='approved' AND u.disabled=0 ORDER BY u.name`,now,s.id,s.teacher_id).all<any>()).results.map(r=>({...r,camera_frame:(u.role!=='student'||u.id===r.student_id)&&!!r.paid&&!r.left_at&&r.last_seen>now-75000&&r.camera_at>now-45000?r.camera_frame:null,camera_at:(u.role!=='student'||u.id===r.student_id)?r.camera_at:null,online:!!r.paid&&!r.left_at&&r.last_seen>now-75000,late:!!r.joined_at&&r.joined_at>s.starts_at}));}
 return {classSessions:sessions,serverNow:now};
}

export async function clearExpiredCameraFrames(db:D1Database,now=Date.now()){await st(db,'UPDATE class_attendance SET camera_frame=NULL,camera_at=NULL WHERE camera_at<=?',now-45000).run()}
