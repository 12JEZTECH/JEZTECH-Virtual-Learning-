import {env} from 'cloudflare:workers';
import {redirect} from 'next/navigation';
import {getChatGPTUser} from './chatgpt-auth';
import {initializeUser} from './service';
import {portalPath} from './portals/service';
export const dynamic='force-dynamic';
export default async function Page(){const identity=await getChatGPTUser();if(!identity)redirect('/login');if(!env.DB)throw new Error('Learning database unavailable');const user=await initializeUser(env.DB,identity,'jezreelch@gmail.com');redirect(portalPath(user.role))}
