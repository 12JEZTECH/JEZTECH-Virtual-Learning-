// Public delivery acknowledgement only. Callback data never grants access;
// authenticated Safaricom checkout queries remain the source of truth.
export const dynamic='force-dynamic';
export async function POST(req:Request){
 if(!req.headers.get('content-type')?.startsWith('application/json'))return Response.json({error:'JSON required'},{status:415});
 const reader=req.body?.getReader();if(!reader)return Response.json({error:'Body required'},{status:400});let bytes=0;const parts:Uint8Array[]=[];
 try{while(true){const {value,done}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>16384){await reader.cancel();return Response.json({error:'Request too large'},{status:413})}parts.push(value)}const body=new Uint8Array(bytes);let offset=0;for(const p of parts){body.set(p,offset);offset+=p.byteLength}const value=JSON.parse(new TextDecoder().decode(body));if(!value?.Body?.stkCallback||typeof value.Body.stkCallback.CheckoutRequestID!=='string')return Response.json({error:'Invalid callback'},{status:400});return Response.json({ResultCode:0,ResultDesc:'Accepted for independent status verification'},{headers:{'Cache-Control':'no-store'}})}catch{return Response.json({error:'Invalid callback'},{status:400})}finally{reader.releaseLock()}
}
