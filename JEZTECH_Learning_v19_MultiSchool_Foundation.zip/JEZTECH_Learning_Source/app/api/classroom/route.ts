import {z} from 'zod';
import {PreparationAction,mutatePreparation,readPreparation} from '../../classroom/preparation';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {initializeUser,AppError} from '../../service';
import {ClassroomAction,readClassroom,readSignals,mutateClassroom} from '../../classroom/service';
export const dynamic='force-dynamic';
async function handle(req:Request,write:boolean){try{const identity=await getChatGPTUser();if(!identity||!env.DB)throw new AppError(401,'Sign-in required');const u=await initializeUser(env.DB,identity,'jezreelch@gmail.com');
 if(!write){const url=new URL(req.url),call=url.searchParams.get('call'),after=Number(url.searchParams.get('after')||0);if(!Number.isSafeInteger(after)||after<0)throw new AppError(400,'Invalid cursor');return Response.json(call?await readSignals(env.DB,u,call,after):{...await readClassroom(env.DB,u),...await readPreparation(env.DB,u)},{headers:{'Cache-Control':'no-store'}})}
 if(req.headers.get('origin')!==new URL(req.url).origin||!req.headers.get('content-type')?.startsWith('application/json'))throw new AppError(403,'Same-origin JSON required');const raw=await req.text();if(raw.length>40000)throw new AppError(413,'Request too large');const parsed=z.union([ClassroomAction,PreparationAction]).parse(JSON.parse(raw));const prep=PreparationAction.safeParse(parsed);return Response.json(prep.success?await mutatePreparation(env.DB,u,prep.data):await mutateClassroom(env.DB,u,ClassroomAction.parse(parsed)),{headers:{'Cache-Control':'no-store'}});
 }catch(e){return Response.json({error:e instanceof AppError?e.message:'Classroom request failed'},{status:e instanceof AppError?e.status:400,headers:{'Cache-Control':'no-store'}})}}
export async function GET(req:Request){return handle(req,false)}
export async function POST(req:Request){return handle(req,true)}
