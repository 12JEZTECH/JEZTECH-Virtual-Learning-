import {env} from 'cloudflare:workers';
import {z} from 'zod';
import {getChatGPTUser} from '../../../chatgpt-auth';
import {initializeUser,AppError} from '../../../service';
export const dynamic='force-dynamic';
const RequestSchema=z.object({studentId:z.string().min(1).max(200),hours:z.number().int().min(1).max(24*90),reason:z.string().trim().max(300).default('')});
export async function POST(req:Request){try{
 const identity=await getChatGPTUser();if(!identity)throw new AppError(401,'Sign in required');
 if(!env.DB)throw new AppError(503,'Database unavailable');
 const user=await initializeUser(env.DB,identity,'jezreelch@gmail.com');
 if(user.role!=='admin')throw new AppError(403,'Platform administrator only');
 if(req.headers.get('origin')!==new URL(req.url).origin||!req.headers.get('content-type')?.startsWith('application/json'))throw new AppError(403,'Same-origin JSON required');
 const raw=await req.text();if(raw.length>2048)throw new AppError(413,'Request too large');
 const body=RequestSchema.parse(JSON.parse(raw));
 const learner=await env.DB.prepare("SELECT id FROM users WHERE id=? AND role='student' AND disabled=0").bind(body.studentId).first();
 if(!learner)throw new AppError(404,'Active learner not found');
 const admission=await env.DB.prepare("SELECT student_id FROM admissions WHERE student_id=? AND status='approved'").bind(body.studentId).first();
 if(!admission)throw new AppError(409,'Approve admission before granting lesson access');
 const now=Date.now(),id=crypto.randomUUID(),expiry=now+body.hours*3600000;
 await env.DB.batch([
 env.DB.prepare('INSERT INTO free_access_grants(id,student_id,scope,starts_at,expires_at,granted_by,reason,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id,body.studentId,'all_materials',now,expiry,user.id,body.reason,now),
 env.DB.prepare('INSERT INTO admin_actions(id,actor_id,action,subject_id,metadata,created_at) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),user.id,'grant_free_access',body.studentId,JSON.stringify({hours:body.hours,grantId:id}),now)
 ]);
 return Response.json({id,expiresAt:expiry},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return Response.json({error:e instanceof AppError?e.message:'Could not grant access'},{status:e instanceof AppError?e.status:400})}}
