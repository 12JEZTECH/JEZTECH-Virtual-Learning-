import {requireChatGPTUser} from '../chatgpt-auth';
import Admission from './request';
export const dynamic='force-dynamic';
export default async function Page(){await requireChatGPTUser('/admission');return <Admission/>}
