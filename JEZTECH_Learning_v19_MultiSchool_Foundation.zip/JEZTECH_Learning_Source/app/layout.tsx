import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "JEZTECH Learning | Classes, lessons and practicals",
  description: "Create assessments, take exams, and monitor sessions with verified accounts and shared records.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
