import {requireChatGPTUser} from '../chatgpt-auth';
import Admission from '../admission/request';
export const dynamic='force-dynamic';
export default async function Register(){await requireChatGPTUser('/register');return <Admission registration/>}
