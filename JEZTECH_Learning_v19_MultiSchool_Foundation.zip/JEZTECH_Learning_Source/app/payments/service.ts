import {z} from 'zod';
import {AppError,type User} from '../service';
import {refreshAccess} from '../classroom/access';
import {requireAdmitted,grantEarnedCredit} from '../engagement/service';
export type PaymentConfig={MPESA_CONSUMER_KEY?:string;MPESA_CONSUMER_SECRET?:string;MPESA_PASSKEY?:string;MPESA_SHORTCODE?:string;MPESA_CALLBACK_URL?:string;MPESA_LIVE_ENABLED?:string};
export const PaymentAction=z.discriminatedUnion('action',[
 z.object({action:z.literal('startPayment'),phone:z.string().trim().min(9).max(20)}),
 z.object({action:z.literal('checkPayment'),id:z.string().uuid()}),
]);
const st=(db:D1Database,sql:string,...v:unknown[])=>db.prepare(sql).bind(...v);
const keys=['MPESA_CONSUMER_KEY','MPESA_CONSUMER_SECRET','MPESA_PASSKEY','MPESA_SHORTCODE','MPESA_CALLBACK_URL','MPESA_LIVE_ENABLED'] as const;
export function paymentConfiguration(c:PaymentConfig){const missing=keys.filter(k=>!c[k]);let callback=false;try{const url=new URL(c.MPESA_CALLBACK_URL||'');callback=url.protocol==='https:'&&!url.username&&!url.password}catch{}return {configured:missing.length===0&&c.MPESA_LIVE_ENABLED==='true'&&c.MPESA_SHORTCODE==='522533'&&callback,missing,mode:'live',requiresPublicCallback:true}}
function config(c:PaymentConfig){if(!paymentConfiguration(c).configured)throw new AppError(503,'Automatic payments are not connected. The administrator must configure live Daraja credentials, the approved Paybill and a public callback gateway.');return {key:c.MPESA_CONSUMER_KEY!,secret:c.MPESA_CONSUMER_SECRET!,pass:c.MPESA_PASSKEY!,short:c.MPESA_SHORTCODE!,callback:c.MPESA_CALLBACK_URL!}}
export function normalisePhone(s:string){const p=s.replace(/[\s+()-]/g,'');const phone=p.startsWith('0')?'254'+p.slice(1):p;if(!/^254[17]\d{8}$/.test(phone))throw new AppError(400,'Enter a valid Kenyan M-Pesa phone number');return phone}
const BASE='https://api.safaricom.co.ke';
type ProviderFetch=typeof fetch;
async function request(fetcher:ProviderFetch,url:string,init:RequestInit){let r:Response;try{r=await fetcher(url,{...init,redirect:'error',signal:AbortSignal.timeout(20000)})}catch{throw new AppError(502,'Safaricom could not be reached. Your payment remains unverified; check again before retrying.')}if(!r.ok)throw new AppError(502,'Safaricom has not confirmed this request. Please check again later.');try{return await r.json() as Record<string,any>}catch{throw new AppError(502,'The payment provider returned an unreadable response')}}
async function credentials(c:PaymentConfig,fetcher:ProviderFetch,now:number){const v=config(c);const auth=await request(fetcher,BASE+'/oauth/v1/generate?grant_type=client_credentials',{headers:{Authorization:'Basic '+btoa(v.key+':'+v.secret)}});if(typeof auth.access_token!=='string'||!auth.access_token)throw new AppError(502,'Payment provider authentication failed');const timestamp=new Date(now+3*3600000).toISOString().slice(0,19).replace(/\D/g,'');return {...v,token:auth.access_token,timestamp,password:btoa(v.short+v.pass+timestamp)}}
async function provider(c:PaymentConfig,path:string,body:Record<string,unknown>,fetcher:ProviderFetch,now:number){const v=await credentials(c,fetcher,now);return request(fetcher,BASE+path,{method:'POST',headers:{Authorization:'Bearer '+v.token,'Content-Type':'application/json'},body:JSON.stringify({BusinessShortCode:v.short,Password:v.password,Timestamp:v.timestamp,...body})})}
function publicIntent(p:any){return {id:p.id,amount:p.amount,days:p.days,status:p.status,message:p.message,created_at:p.created_at,confirmed_at:p.confirmed_at,reference:p.checkout_id}}
export async function readPayments(db:D1Database,u:User,c:PaymentConfig){const status=paymentConfiguration(c);const plan=await st(db,"SELECT price,days FROM subscription_settings WHERE id='main'").first<{price:number;days:number}>();const admission=u.role==='student'?await st(db,'SELECT phone FROM admissions WHERE student_id=?',u.id).first<{phone:string}>():null;return {plan,phone:admission?.phone||'',configuration:u.role==='admin'?status:{configured:status.configured},paymentIntents:u.role==='student'?(await st(db,'SELECT * FROM payment_intents WHERE student_id=? ORDER BY created_at DESC LIMIT 20',u.id).all<any>()).results.map(publicIntent):[]}}
export async function confirmIntent(db:D1Database,id:string,now:number){
 // Only call after a successful authenticated query to Safaricom. Idempotent D1 batch.
 const p=await st(db,'SELECT * FROM payment_intents WHERE id=?',id).first<any>();if(!p||!p.checkout_id)throw new AppError(404,'Payment request not found');
 await db.batch([
 st(db,`INSERT INTO subscriptions(id,student_id,phone,receipt,amount,days,status,verified_at,expires_at,note,created_at) SELECT id,student_id,phone,'STK:'||checkout_id,amount,days,'verified',?,MAX(?,COALESCE((SELECT MAX(expires_at) FROM subscriptions WHERE student_id=payment_intents.student_id AND status='verified'),0))+days*86400000,'Automatically confirmed by authenticated Safaricom STK query; reference is the checkout ID',created_at FROM payment_intents WHERE id=? AND status IN ('pending','confirmed') ON CONFLICT(id) DO NOTHING`,now,now,id),
 st(db,"UPDATE payment_intents SET status='confirmed',confirmed_at=COALESCE(confirmed_at,?),message='Payment confirmed by Safaricom. Learner access is active.' WHERE id=? AND EXISTS(SELECT 1 FROM subscriptions WHERE id=? AND status='verified')",now,id,id),
 ]);await refreshAccess(db,p.student_id,now);await grantEarnedCredit(db,p.student_id,now);
}
async function check(db:D1Database,p:any,c:PaymentConfig,now:number,fetcher:ProviderFetch){
 if(p.status==='confirmed'){await refreshAccess(db,p.student_id,now);await grantEarnedCredit(db,p.student_id,now);return publicIntent(p)}if(p.status!=='pending'||!p.checkout_id)return publicIntent(p);
 const lock=await st(db,'UPDATE payment_intents SET checked_at=? WHERE id=? AND (checked_at IS NULL OR checked_at<=?)',now,p.id,now-10000).run();if(!lock.meta.changes)return publicIntent(p);
 const data=await provider(c,'/mpesa/stkpushquery/v1/query',{CheckoutRequestID:p.checkout_id},fetcher,now);
 if(data.CheckoutRequestID!==p.checkout_id||data.MerchantRequestID!==p.merchant_id)throw new AppError(502,'Payment provider response did not match the original request');
 if(data.ResultCode===0||data.ResultCode==='0')await confirmIntent(db,p.id,now);
 else if(['1032','1037','1','2001'].includes(String(data.ResultCode)))await st(db,"UPDATE payment_intents SET status='failed',message='Payment was cancelled, timed out or declined. No access has been granted.' WHERE id=? AND status='pending'",p.id).run();
 return publicIntent(await st(db,'SELECT * FROM payment_intents WHERE id=?',p.id).first());
}
export async function mutatePayment(db:D1Database,u:User,a:z.infer<typeof PaymentAction>,c:PaymentConfig,now=Date.now(),fetcher:ProviderFetch=fetch){
 if(u.role!=='student')throw new AppError(403,'Learner account required');await requireAdmitted(db,u);if(!await st(db,"SELECT id FROM registration_fee_payments WHERE student_id=? AND status='verified'",u.id).first()&&!await st(db,"SELECT id FROM subscriptions WHERE student_id=? AND status='verified' LIMIT 1",u.id).first())throw new AppError(403,'Your registration fee must be verified before tuition can be activated.');
 if(a.action==='checkPayment'){const p=await st(db,'SELECT * FROM payment_intents WHERE id=? AND student_id=?',a.id,u.id).first<any>();if(!p)throw new AppError(404,'Payment request not found');return check(db,p,c,now,fetcher)}
 const v=config(c),phone=normalisePhone(a.phone);const plan=await st(db,"SELECT price,days FROM subscription_settings WHERE id='main'").first<{price:number;days:number}>();if(!plan||plan.price<1)throw new AppError(409,'The administrator must set the subscription fee and period first');
 const pending=await st(db,"SELECT * FROM payment_intents WHERE student_id=? AND status IN ('starting','pending','unknown') AND created_at>? ORDER BY created_at DESC LIMIT 1",u.id,now-600000).first<any>();if(pending)return publicIntent(pending);
 const recent=await st(db,'SELECT id FROM payment_intents WHERE student_id=? AND created_at>?',u.id,now-30000).first();if(recent)throw new AppError(429,'Wait before requesting another payment prompt');
 const id=crypto.randomUUID();try{const inserted=await st(db,"INSERT INTO payment_intents(id,student_id,phone,amount,days,created_at) SELECT ?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM payment_intents WHERE student_id=? AND status IN ('starting','pending','unknown') AND created_at>?)",id,u.id,phone,plan.price,plan.days,now,u.id,now-600000).run();if(!inserted.meta.changes)throw new Error('Existing payment request')}catch{throw new AppError(409,'Another payment request is being created. Refresh your payment status.')}
 try{const data=await provider(c,'/mpesa/stkpush/v1/processrequest',{TransactionType:'CustomerPayBillOnline',Amount:plan.price,PartyA:phone,PartyB:v.short,PhoneNumber:phone,CallBackURL:v.callback,AccountReference:'8075575',TransactionDesc:'JEZTECH learning'},fetcher,now);
 if(String(data.ResponseCode)!=='0'||typeof data.CheckoutRequestID!=='string'||typeof data.MerchantRequestID!=='string')throw new AppError(502,'Safaricom has not accepted the payment prompt');
 await st(db,"UPDATE payment_intents SET checkout_id=?,merchant_id=?,status='pending',message='Approve the M-Pesa prompt on your phone. Waiting for Safaricom confirmation.' WHERE id=?",data.CheckoutRequestID,data.MerchantRequestID,id).run();
 }catch(e){await st(db,"UPDATE payment_intents SET status='unknown',message='Prompt status is uncertain. Check your M-Pesa account before making another payment; contact the administrator if charged.' WHERE id=?",id).run();throw e}
 return publicIntent(await st(db,'SELECT * FROM payment_intents WHERE id=?',id).first());
}
export async function reconcilePayments(db:D1Database,c:PaymentConfig,now=Date.now(),fetcher:ProviderFetch=fetch){if(!paymentConfiguration(c).configured)return {connected:false,checked:0};const rows=(await st(db,"SELECT * FROM payment_intents WHERE status='pending' ORDER BY COALESCE(checked_at,0) LIMIT 5").all<any>()).results;let checked=0;for(const p of rows){try{await check(db,p,c,now,fetcher);checked++}catch{ /* Leave unverified for a later authenticated retry. */ }}return {connected:true,checked}}
