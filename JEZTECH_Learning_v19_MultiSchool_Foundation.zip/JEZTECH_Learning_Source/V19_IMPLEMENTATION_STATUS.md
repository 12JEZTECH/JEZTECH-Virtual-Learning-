# JEZTECH Learning v19 – implementation status

## Added in this source
- Registration selects class/level only; server selects an available teacher automatically (temporary fallback, not tenant-aware scheduling).
- CBC PP1/PP2 and Grades 1–12; 8-4-4 Forms 1–4 selectable. These are level selectors, **not full lesson content**.
- Additive D1 schema for schools, memberships, subscriptions, class channels, enrollments, streams, admin grants and audit records.
- Admin-only free lesson grant API and a simple form at `/admin/free-lessons`.
- Promotional grants accepted by the lesson access check.
- Teacher-facing subscription and registration finance data removed from engagement API payload.
- Consistent minimum button dimensions.

## NOT yet complete
- Full tenant isolation across existing services; tenant-aware login/role enforcement, school admin workflows and subscription billing. Do not onboard real schools until these are implemented and tested.
- Live multi-class broadcast transport, recording/transcoding and streaming delivery. Database tables only.
- Complete KICD-aligned tutorials/content for all levels; selectors only.
- Supabase migration from Cloudflare D1, Vercel/Render runtime deployment, CI/CD and production environment setup.
- Automatic school-aware teacher assignment and school self-registration.
- End-to-end regression tests, payment provider verification, production migration tests.
- Trial grant integration into every media/video/virtual-lab endpoint (lesson check only at present).

## Deployment safety
This package retains the existing Cloudflare D1 architecture. Applying its D1 migration on Supabase PostgreSQL will fail. Do not expose the multi-tenant data model as production tenant isolation. Take backups, test migrations on a staging D1 clone and audit authorization on every endpoint. The registration-fee receipt review is manual; M-Pesa live reconciliation requires a verified provider feed.
